# school management system (sms-backend)

school management system

## Install the dependencies

```bash
npm install
```

## Start The App

```bash
npm start
```
