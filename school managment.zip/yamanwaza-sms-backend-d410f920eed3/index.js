const express = require('express');
const morgan = require('morgan');
require('dotenv').config();
const Router = require('./router');
const cors = require('cors');
const { handleError } = require('./src/utils/error');
const __send = require('./src/utils/__send');

const app = express();

const db = require('./src/services/sequelize');

db.sequelize
	.authenticate()
	.then((_) => {
		console.log('Database Connection has been established successfully.');
	})
	.catch((error) => {
		console.error('Unable to connect to the database:\n', error);
	});
// const models = require('./src/models/index');

app.use(cors());
app.use(express.json());
app.use(morgan('dev'));
app.use(__send);

const path = require('path');
app.use('/public', express.static(path.join(__dirname, 'src/public')));

app.use('/', Router);

// Error Handler Middleware
app.use((err, req, res, next) => {
	handleError(err, res);
});

// db.sequelize.sync({ force: true }).then((_) => {
// 	app.listen(process.env.PORT, () => {
// 		console.log(`Listening on Port ${process.env.PORT}`);
// 	});
// });

app.listen(process.env.PORT, () => {
	console.log(`Listening on Port ${process.env.PORT}`);
});
