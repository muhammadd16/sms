const express = require('express');
const app = express();
const Auth = require('./src/modules/auth-v2/router');
const SchoolManagement = require('./src/modules/school-management-v3/router');
const Marks = require('./src/modules/marks/router');
const Schedules = require('./src/modules/schedules/router');
const Attendance = require('./src/modules/attendance/router');
const Events = require('./src/modules/events/router');

app.use('/auth', Auth);
app.use('/school-management', SchoolManagement);
app.use('/marks', Marks);
app.use('/schedules', Schedules);
app.use('/attendance', Attendance);
app.use('/events', Events);

module.exports = app;
