const { Sequelize, DataTypes } = require('sequelize');
const { sequelize } = require('../services/sequelize');
const Sections = require('./sections');
const Subjects = require('./subjects');

const Classes = sequelize.define('Classes', {
	id: {
		type: Sequelize.INTEGER,
		primaryKey: true,
		autoIncrement: true,
	},
	schoolId: {
		type: Sequelize.INTEGER,
		allowNull: false,
	},
	name: {
		type: DataTypes.STRING,
		allowNull: false,
	},
});

Classes.hasMany(Sections, {
	foreignKey: 'classId',
	onDelete: 'CASCADE',
	as: 'sections',
});

Classes.hasMany(Subjects, {
	foreignKey: 'classId',
	onDelete: 'CASCADE',
	as: 'subjects',
});

// Classes.sync({ alter: true })
// 	.then((_) => {
// 		console.log('Classes model was synchronized successfully');
// 	})
// 	.catch((err) => {
// 		console.log(err);
// 	});

module.exports = Classes;
