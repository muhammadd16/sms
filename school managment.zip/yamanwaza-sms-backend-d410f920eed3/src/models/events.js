const { Sequelize, DataTypes } = require('sequelize');
const { sequelize } = require('../services/sequelize');
const Classes = require('./classes');
const Sections = require('./sections');

const Events = sequelize.define('Events', {
	id: {
		type: Sequelize.INTEGER,
		primaryKey: true,
		autoIncrement: true,
	},
	schoolId: {
		type: Sequelize.INTEGER,
		allowNull: false,
	},
	classId: {
		type: Sequelize.INTEGER,
		allowNull: false,
	},
	sectionId: {
		type: Sequelize.INTEGER,
		allowNull: false,
	},
	name: {
		type: DataTypes.STRING,
		allowNull: false,
	},
	description: {
		type: DataTypes.TEXT,
		allowNull: true,
	},
	type: {
		type: DataTypes.STRING,
		allowNull: false,
	},
	date: {
		type: DataTypes.DATE,
		allowNull: false,
	},
});

Events.hasOne(Classes, {
	sourceKey: 'classId',
	foreignKey: 'id',
	as: 'class',
});

Events.hasOne(Sections, {
	sourceKey: 'sectionId',
	foreignKey: 'id',
	as: 'section',
});

// Events.sync({ alter: true })
// 	.then((_) => {
// 		console.log('Events model was synchronized successfully');
// 	})
// 	.catch((err) => {
// 		console.log(err);
// 	});

module.exports = Events;
