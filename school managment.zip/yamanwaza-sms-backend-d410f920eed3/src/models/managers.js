const { Sequelize, DataTypes } = require('sequelize');
const { sequelize } = require('../services/sequelize');
const Schools = require('./schools');

const Managers = sequelize.define('Managers', {
	id: {
		type: Sequelize.INTEGER,
		primaryKey: true,
		autoIncrement: true,
	},
	firstName: {
		type: DataTypes.STRING,
		allowNull: false,
	},
	lastName: {
		type: DataTypes.STRING,
		allowNull: false,
	},
	gender: {
		type: DataTypes.STRING,
		allowNull: false,
		validate: {
			isIn: ['male', 'female'],
		},
	},
	email: {
		type: DataTypes.STRING,
		allowNull: false,
		validate: {
			isEmail: true,
		},
	},
	password: {
		type: DataTypes.STRING,
		allowNull: false,
	},
	isVerified: {
		type: DataTypes.BOOLEAN,
		defaultValue: false,
	},
	picture: {
		type: DataTypes.STRING,
	},
});

Managers.hasOne(Schools, { foreignKey: { name: 'managerId' }, as: 'school' });

// Managers.sync({ alter: true })
// 	.then((_) => {
// 		console.log('Managers model was synchronized successfully');
// 	})
// 	.catch((err) => {
// 		console.log(err);
// 	});

module.exports = Managers;
