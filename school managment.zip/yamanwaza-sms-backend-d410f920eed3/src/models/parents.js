const { Sequelize, DataTypes } = require('sequelize');
const { sequelize } = require('../services/sequelize');
const Students = require('./students');
const Schools = require('./schools');

const Parents = sequelize.define('Parents', {
	id: {
		type: Sequelize.INTEGER,
		primaryKey: true,
		autoIncrement: true,
	},
	schoolId: {
		type: Sequelize.INTEGER,
		allowNull: false,
	},
	serial: {
		type: Sequelize.INTEGER,
		allowNull: false,
	},
	childId: {
		type: Sequelize.INTEGER,
		allowNull: false,
	},
	firstName: {
		type: DataTypes.STRING,
		allowNull: false,
	},
	lastName: {
		type: DataTypes.STRING,
		allowNull: false,
	},
	email: {
		type: DataTypes.STRING,
		allowNull: false,
		validate: {
			isEmail: true,
		},
	},
	password: {
		type: DataTypes.STRING,
		allowNull: false,
	},
});

Parents.belongsTo(Students, {
	foreignKey: 'childId',
	as: 'child',
});

Parents.belongsTo(Schools, {
	foreignKey: 'schoolId',
	as: 'school',
});

// Parents.sync({ force: true })
// 	.then((_) => {
// 		console.log('Parents model was synchronized successfully');
// 	})
// 	.catch((err) => {
// 		console.log(err);
// 	});

module.exports = Parents;
