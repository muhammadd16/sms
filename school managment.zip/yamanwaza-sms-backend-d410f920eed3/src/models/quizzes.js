const { Sequelize, DataTypes } = require('sequelize');
const { sequelize } = require('../services/sequelize');
const StudentsMarks = require('./students-marks');
const Subjects = require('./subjects');

const Quizzes = sequelize.define('Quizzes', {
	id: {
		type: Sequelize.INTEGER,
		primaryKey: true,
		autoIncrement: true,
	},
	schoolId: {
		type: Sequelize.INTEGER,
		allowNull: false,
	},
	subjectId: {
		type: DataTypes.INTEGER,
		allowNull: false,
	},
	name: {
		type: DataTypes.STRING,
		allowNull: false,
	},
	fullMark: {
		type: DataTypes.INTEGER,
		allowNull: false,
	},
	successMark: {
		type: DataTypes.INTEGER,
		allowNull: false,
	},
});

Quizzes.hasMany(StudentsMarks, {
	foreignKey: 'quizId',
	as: 'marks',
});

StudentsMarks.hasOne(Quizzes, {
	sourceKey: 'quizId',
	foreignKey: 'id',
	as: 'quiz',
});

Quizzes.hasOne(Subjects, {
	sourceKey: 'subjectId',
	foreignKey: 'id',
	as: 'subject',
});

// Quizzes.sync({ alter: true })
// 	.then((_) => {
// 		console.log('Quizzes model was synchronized successfully');
// 	})
// 	.catch((err) => {
// 		console.log(err);
// 	});

module.exports = Quizzes;
