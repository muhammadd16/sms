const { Sequelize, DataTypes } = require('sequelize');
const { sequelize } = require('../services/sequelize');
const Subjects = require('./subjects');
const Teachers = require('./teachers');

const SchedulePeriods = sequelize.define('SchedulePeriods', {
	id: {
		type: DataTypes.INTEGER,
		primaryKey: true,
		autoIncrement: true,
	},
	scheduleId: {
		type: DataTypes.INTEGER,
		allowNull: false,
	},
	day: {
		type: DataTypes.STRING,
		allowNull: false,
	},
	period: {
		type: DataTypes.INTEGER,
		allowNull: false,
	},
	teacherId: {
		type: DataTypes.INTEGER,
		allowNull: false,
	},
	subjectId: {
		type: DataTypes.INTEGER,
		allowNull: false,
	},
});

SchedulePeriods.hasOne(Subjects, {
	sourceKey: 'subjectId',
	foreignKey: 'id',
	as: 'subject',
});
SchedulePeriods.hasOne(Teachers, {
	sourceKey: 'teacherId',
	foreignKey: 'id',
	as: 'teacher',
});

// SchedulePeriods.sync({ alter: true })
// 	.then((_) => {
// 		console.log('SchedulePeriods model was synchronized successfully');
// 	})
// 	.catch((err) => {
// 		console.log(err);
// 	});

module.exports = SchedulePeriods;
