const { Sequelize, DataTypes } = require('sequelize');
const { sequelize } = require('../services/sequelize');
const SchedulePeriods = require('./schedule-periods');
const Classes = require('./classes');
const Sections = require('./sections');

const Schedules = sequelize.define('Schedules', {
	id: {
		type: DataTypes.INTEGER,
		primaryKey: true,
		autoIncrement: true,
	},
	schoolId: {
		type: DataTypes.INTEGER,
		allowNull: false,
	},
	classId: {
		type: DataTypes.INTEGER,
		allowNull: false,
	},
	sectionId: {
		type: DataTypes.INTEGER,
		allowNull: false,
	},
});

Schedules.hasMany(SchedulePeriods, {
	foreignKey: 'scheduleId',
	as: 'periods',
});

SchedulePeriods.hasOne(Schedules, {
	sourceKey: 'scheduleId',
	foreignKey: 'id',
	as: 'schedule',
});

Schedules.hasOne(Classes, {
	sourceKey: 'classId',
	foreignKey: 'id',
	as: 'class',
});

Schedules.hasOne(Sections, {
	sourceKey: 'sectionId',
	foreignKey: 'id',
	as: 'section',
});

// Schedules.sync({ alter: true })
// 	.then((_) => {
// 		console.log('Schedules model was synchronized successfully');
// 	})
// 	.catch((err) => {
// 		console.log(err);
// 	});

module.exports = Schedules;
