const { Sequelize, DataTypes } = require('sequelize');
const { sequelize } = require('../services/sequelize');
const Classes = require('./classes');
const TeachersAttendance = require('./teacher-attendance');
const Teachers = require('./teachers');

const Schools = sequelize.define('Schools', {
	id: {
		type: DataTypes.INTEGER,
		primaryKey: true,
		autoIncrement: true,
	},
	managerId: {
		type: DataTypes.INTEGER,
		allowNull: false,
	},
	name: {
		type: DataTypes.STRING,
		allowNull: false,
	},
	address: {
		type: DataTypes.STRING,
		allowNull: false,
	},
	phone: {
		type: DataTypes.STRING,
		allowNull: false,
	},
	eduStage: {
		type: DataTypes.STRING,
		allowNull: false,
	},
	logo: {
		type: DataTypes.STRING,
	},
});

Schools.hasMany(Classes, {
	foreignKey: 'schoolId',
	onDelete: 'CASCADE',
	as: 'classes',
});

Schools.hasMany(TeachersAttendance, {
	foreignKey: 'schoolId',
});

Teachers.belongsTo(Schools, {
	foreignKey: 'schoolId',
	as: 'school',
});

// Schools.sync({ alter: true })
// 	.then((_) => {
// 		console.log('Schools model was synchronized successfully');
// 	})
// 	.catch((err) => {
// 		console.log(err);
// 	});

module.exports = Schools;
