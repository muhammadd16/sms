const { Sequelize, DataTypes } = require('sequelize');
const { sequelize } = require('../services/sequelize');
const Sections = sequelize.define('Sections', {
	id: {
		type: Sequelize.INTEGER,
		primaryKey: true,
		autoIncrement: true,
	},
	classId: {
		type: Sequelize.INTEGER,
		allowNull: false,
	},
	name: {
		type: DataTypes.STRING,
		allowNull: false,
	},
});

// Sections.sync({ alter: true })
// 	.then((_) => {
// 		console.log('Sections model was synchronized successfully');
// 	})
// 	.catch((err) => {
// 		console.log(err);
// 	});

module.exports = Sections;
