const { Sequelize, DataTypes } = require('sequelize');
const { sequelize } = require('../services/sequelize');
const StudentsAttendances = require('./students-attendances');
const Classes = require('./classes');
const Sections = require('./sections');

const StudentAttendance = sequelize.define('StudentAttendance', {
	id: {
		type: Sequelize.INTEGER,
		primaryKey: true,
		autoIncrement: true,
	},
	schoolId: {
		type: Sequelize.INTEGER,
		allowNull: false,
	},
	classId: {
		type: Sequelize.INTEGER,
		allowNull: false,
	},
	sectionId: {
		type: Sequelize.INTEGER,
		allowNull: false,
	},
	date: {
		type: Sequelize.DATEONLY,
		allowNull: false,
		defaultValue: new Date(),
	},
});

StudentAttendance.hasMany(StudentsAttendances, {
	foreignKey: 'attendanceId',
	as: 'students',
});

StudentsAttendances.belongsTo(StudentAttendance, {
	foreignKey: 'attendanceId',
	as: 'attendance',
});

StudentAttendance.hasOne(Classes, {
	sourceKey: 'classId',
	foreignKey: 'id',
	as: 'class',
});
StudentAttendance.hasOne(Sections, {
	sourceKey: 'sectionId',
	foreignKey: 'id',
	as: 'section',
});

// StudentAttendance.sync({ alter: true })
// 	.then((_) => {
// 		console.log('StudentsAttendance model was synchronized successfully');
// 	})
// 	.catch((err) => {
// 		console.log(err);
// 	});

module.exports = StudentAttendance;
