const { Sequelize, DataTypes } = require('sequelize');
const { sequelize } = require('../services/sequelize');
const Students = require('./students');

const StudentsAttendances = sequelize.define('StudentsAttendances', {
	id: {
		type: Sequelize.INTEGER,
		primaryKey: true,
		autoIncrement: true,
	},
	studentId: {
		type: Sequelize.INTEGER,
		allowNull: false,
	},
	attendanceId: {
		type: Sequelize.INTEGER,
		allowNull: false,
	},
	state: {
		type: DataTypes.STRING,
		allowNull: false,
	},
	reason: {
		type: DataTypes.STRING,
		defaultValue: null,
	},
});

StudentsAttendances.hasOne(Students, {
	sourceKey: 'studentId',
	foreignKey: 'id',
	as: 'student',
});

// StudentsAttendances.sync({ alter: true })
// 	.then((_) => {
// 		console.log('StudentsAttendances model was synchronized successfully');
// 	})
// 	.catch((err) => {
// 		console.log(err);
// 	});

module.exports = StudentsAttendances;
