const { Sequelize, DataTypes } = require('sequelize');
const { sequelize } = require('../services/sequelize');
const Students = require('./students');

const StudentsMarks = sequelize.define('StudentsMarks', {
	id: {
		type: Sequelize.INTEGER,
		primaryKey: true,
		autoIncrement: true,
	},
	studentId: {
		type: DataTypes.INTEGER,
		allowNull: false,
	},
	quizId: {
		type: DataTypes.INTEGER,
		allowNull: false,
	},
	mark: {
		type: DataTypes.INTEGER,
		allowNull: false,
	},
});

StudentsMarks.belongsTo(Students, {
	foreignKey: 'studentId',
	targetKey: 'id',
	as: 'student',
});

// StudentsMarks.sync({ alter: true })
// 	.then((_) => {
// 		console.log('StudentsMarks model was synchronized successfully');
// 	})
// 	.catch((err) => {
// 		console.log(err);
// 	});

module.exports = StudentsMarks;
