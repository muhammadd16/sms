const { Sequelize, DataTypes } = require('sequelize');
const { sequelize } = require('../services/sequelize');
const Classes = require('./classes');
const Sections = require('./sections');
const Schools = require('./schools');

const Students = sequelize.define('Students', {
	id: {
		type: Sequelize.INTEGER,
		primaryKey: true,
		autoIncrement: true,
	},
	schoolId: {
		type: Sequelize.INTEGER,
		allowNull: false,
	},
	classId: {
		type: Sequelize.INTEGER,
		allowNull: false,
	},
	sectionId: {
		type: Sequelize.INTEGER,
		allowNull: false,
	},
	serial: {
		type: Sequelize.INTEGER,
		allowNull: false,
	},
	firstName: {
		type: DataTypes.STRING,
		allowNull: false,
	},
	lastName: {
		type: DataTypes.STRING,
		allowNull: false,
	},
	fatherName: {
		type: DataTypes.STRING,
		allowNull: false,
	},
	motherName: {
		type: DataTypes.STRING,
		allowNull: false,
	},
	gender: {
		type: DataTypes.STRING,
		allowNull: false,
	},
	email: {
		type: DataTypes.STRING,
		allowNull: false,
		validate: {
			isEmail: true,
		},
	},
	password: {
		type: DataTypes.STRING,
		allowNull: false,
	},
	isVerified: {
		type: DataTypes.BOOLEAN,
		defaultValue: true,
	},
	picture: {
		type: DataTypes.STRING,
	},
});

Students.belongsTo(Classes, {
	foreignKey: 'classId',
	as: 'class',
});

Students.belongsTo(Sections, {
	foreignKey: 'sectionId',
	as: 'section',
});

Students.belongsTo(Schools, {
	foreignKey: 'schoolId',
	as: 'school',
});

// Students.sync({ alter: true })
// 	.then((_) => {
// 		console.log('Students model was synchronized successfully');
// 	})
// 	.catch((err) => {
// 		console.log(err);
// 	});

module.exports = Students;
