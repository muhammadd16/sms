const { Sequelize, DataTypes } = require('sequelize');
const { sequelize } = require('../services/sequelize');
const TeachersAttendances = require('./teacher-attendances');



const TeachersAttendance = sequelize.define('TeacherAttendance', {
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    schoolId: {
        type: Sequelize.INTEGER,
        allowNull: false,
    },
    date: {
        type: Sequelize.DATEONLY,
        allowNull: false,
        defaultValue: new Date()

    },

});
TeachersAttendance.hasMany(TeachersAttendances, {
    foreignKey: 'attendanceId',
    as: 'teachers',
});

TeachersAttendances.belongsTo(TeachersAttendance, {
    foreignKey: 'attendanceId',
    as: 'attendance',
});


/*TeachersAttendance.sync({ alter: true })
    .then((_) => {
        console.log('StudentsAttendances model was synchronized successfully');
    })
    .catch((err) => {
        console.log(err);
    });
*/



module.exports = TeachersAttendance;