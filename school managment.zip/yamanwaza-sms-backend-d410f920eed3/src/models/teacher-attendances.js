const { Sequelize, DataTypes } = require('sequelize');
const { sequelize } = require('../services/sequelize');
const TeachersAttendance = require('./teacher-attendance');
const Teachers = require('./teachers');

const TeachersAttendances = sequelize.define('TeachersAttendances', {
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    teacherId: {
        type: Sequelize.INTEGER,
        allowNull: false,
    },
    attendanceId: {
        type: Sequelize.INTEGER,
        allowNull: false,
    },
    state: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    reason: {
        type: DataTypes.STRING,
        defaultValue: null,
    },

});
TeachersAttendances.hasOne(Teachers, {
    sourceKey: 'teacherId',
    foreignKey: 'id',
    as: 'teacher',
});


/*TeachersAttendances.sync({ force: true })
    .then((_) => {
        console.log('TeachersAttendances model was synchronized successfully');
    })
    .catch((err) => {
        console.log(err);
    });

*/


module.exports = TeachersAttendances;
