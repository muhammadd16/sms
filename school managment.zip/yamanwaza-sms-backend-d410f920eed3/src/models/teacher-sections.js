const { Sequelize, DataTypes } = require('sequelize');
const { sequelize } = require('../services/sequelize');
const Sections = require('./sections');
const Teachers = require('./teachers');

const TeacherSections = sequelize.define('TeacherSections', {
	id: {
		type: Sequelize.INTEGER,
		primaryKey: true,
		autoIncrement: true,
	},
	teacherId: {
		type: Sequelize.INTEGER,
		allowNull: false,
	},
	sectionId: {
		type: Sequelize.INTEGER,
		allowNull: false,
	},
});

Teachers.hasMany(TeacherSections, { foreignKey: 'teacherId', as: 'sections' });
Sections.hasMany(TeacherSections, { foreignKey: 'sectionId', as: 'teachers' });

// TeacherSections.sync({ force: true })
// 	.then((_) => {
// 		console.log('TeacherSections model was synchronized successfully');
// 	})
// 	.catch((err) => {
// 		console.log(err);
// 	});

module.exports = TeacherSections;
