const { Sequelize, DataTypes } = require('sequelize');
const { sequelize } = require('../services/sequelize');
const Subjects = require('./subjects');
const Teachers = require('./teachers');

const TeacherSubjects = sequelize.define('TeacherSubjects', {
	id: {
		type: Sequelize.INTEGER,
		primaryKey: true,
		autoIncrement: true,
	},
	teacherId: {
		type: Sequelize.INTEGER,
		allowNull: false,
	},
	subjectId: {
		type: Sequelize.INTEGER,
		allowNull: false,
	},
});

Teachers.hasMany(TeacherSubjects, { foreignKey: 'teacherId', as: 'subjects' });
Subjects.hasMany(TeacherSubjects, { foreignKey: 'subjectId', as: 'teachers' });
TeacherSubjects.belongsTo(Subjects, {
	foreignKey: 'subjectId',
	as: 'subject',
});

// TeacherSubjects.sync({ force: true })
// 	.then((_) => {
// 		console.log('TeacherSubjects model was synchronized successfully');
// 	})
// 	.catch((err) => {
// 		console.log(err);
// 	});

module.exports = TeacherSubjects;
