const { Sequelize, DataTypes } = require('sequelize');
const { sequelize } = require('../services/sequelize');
const Schools = require('./schools');
const Classes = require('./classes');
const Sections = require('./sections');

const Teachers = sequelize.define('Teachers', {
	id: {
		type: Sequelize.INTEGER,
		primaryKey: true,
		autoIncrement: true,
	},
	schoolId: {
		type: Sequelize.INTEGER,
		allowNull: false,
	},
	serial: {
		type: Sequelize.INTEGER,
		allowNull: false,
	},
	firstName: {
		type: DataTypes.STRING,
		allowNull: false,
	},
	lastName: {
		type: DataTypes.STRING,
		allowNull: false,
	},
	gender: {
		type: DataTypes.STRING,
		allowNull: false,
		validate: {
			isIn: ['male', 'female'],
		},
	},
	grade: {
		type: DataTypes.STRING,
		allowNull: false,
	},
	email: {
		type: DataTypes.STRING,
		allowNull: false,
		validate: {
			isEmail: true,
		},
	},
	password: {
		type: DataTypes.STRING,
		allowNull: false,
	},
	isVerified: {
		type: DataTypes.BOOLEAN,
		defaultValue: true,
	},
	picture: {
		type: DataTypes.STRING,
	},
});

Teachers.belongsTo(Classes, {
	foreignKey: 'classId',
	as: 'class',
});

Teachers.belongsTo(Sections, {
	foreignKey: 'sectionId',
	as: 'section',
});

// Teachers.sync({ alter: true }).then((_) => {
// 	console.log('Teachers model was synchronized successfully');
// });

module.exports = Teachers;
