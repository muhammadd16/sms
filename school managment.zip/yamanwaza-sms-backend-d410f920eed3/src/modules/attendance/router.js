const express = require('express');
const app = express();
const Teacher = require('./teacher/router');
const Student = require('./student/router');

app.use('/teacher', Teacher);
app.use('/student', Student);

module.exports = app;
