const express = require('express');
const { ErrorHandler } = require('../../../utils/error');
const { validationResult, body } = require('express-validator');
const { StatusCodes } = require('http-status-codes');
const { defaults } = require('../../../utils/config');
const model = require('./model');

module.exports = {
	async createStudentsAttendance(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let schoolId = req.body.__user.school.id;
				let body = req.body;
				console.log(body);
				await model.createStudentAttendance(body, schoolId);
				res.__send(StatusCodes.CREATED);
			} catch (err) {
				next(err);
			}
		}
	},
	async getStudentsAttendance(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let schoolId = req.body.__user.school.id;
				//let studentId = +req.params['studentId'];
				let limit = +req.query['limit'] || defaults.limit;
				let offset = +req.query['offset'] || defaults.offset;
				let data = await model.getStudentsAttendance(schoolId, { limit, offset });
				res.__send(StatusCodes.OK, data);
			} catch (err) {
				next(err);
			}
		}
	},
	async getAttendanceById(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				//let schoolId = req.body.__user.school.id;
				let id = +req.params['id'];
				let data = await model.getStudentsAttendanceById(id);
				res.__send(StatusCodes.OK, data);
			} catch (err) {
				next(err);
			}
		}
	},
	async getStudentsAttendanceByStudentId(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				//let schoolId = req.body.__user.school.id;
				let studentId = +req.params['studentId'];
				const tenDaysAgo = new Date(new Date().setDate(new Date().getDate() - 10));
				let from = req.query['from'] || tenDaysAgo;
				let to = req.query['to'] || new Date();
				let data = await model.getStudentsAttendanceByStudentId(studentId, from, to);
				res.__send(StatusCodes.OK, data);
			} catch (err) {
				next(err);
			}
		}
	},
	async updateStudentsAttendance(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let StudentsAttendance = req.body.StudentsAttendance[0].students;
				for (let i = 0; i < StudentsAttendance.length; i++)
					await model.updateStudentsAttendance(
						StudentsAttendance[i],
						StudentsAttendance[i].studentId,
					);
				res.__send(StatusCodes.OK);
			} catch (err) {
				next(err);
			}
		}
	},

	async deleteAttendance(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let attendanceId = +req.params['attendanceId'];

				await model.deleteAttendance(attendanceId);
				res.__send(StatusCodes.OK);
			} catch (err) {
				next(err);
			}
		}
	},
};
