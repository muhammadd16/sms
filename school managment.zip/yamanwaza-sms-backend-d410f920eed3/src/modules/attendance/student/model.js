const StudentAttendance = require('../../../models/student-attendance');
const StudentsAttendances = require('../../../models/students-attendances');
const Students = require('../../../models/students');
const { sequelize } = require('../../../services/sequelize');
const { Op } = require('sequelize');
const Classes = require('../../../models/classes');
const Sections = require('../../../models/sections');

module.exports = {
	async createStudentAttendance(data, schoolId) {
		data.schoolId = schoolId;
		const att = await StudentAttendance.create(data, {
			include: [
				{
					model: StudentsAttendances,
					as: 'students',
				},
			],
		});
		return att.dataValues;
	},
	async getStudentsAttendance(schoolId, { limit, offset }, filters = {}) {
		const data = await StudentAttendance.findAndCountAll({
			where: { schoolId, ...filters },
			limit,
			offset,
			include: [
				{
					model: StudentsAttendances,
					as: 'students',
				},
				{
					model: Classes,
					as: 'class',
				},
				{
					model: Sections,
					as: 'section',
				},
			],
		});
		return data;
	},
	async getStudentsAttendanceByStudentId(studentId, from, to) {
		const data = await StudentsAttendances.findAll({
			where: { studentId },
			include: [
				{
					model: StudentAttendance,
					as: 'attendance',
					where: {
						date: {
							[Op.between]: [from, to],
						},
					},
				},
			],
		});
		return data;
	},
	async getStudentsAttendanceById(id) {
		const data = await StudentAttendance.findOne({
			include: [
				{
					model: StudentsAttendances,
					as: 'students',
					include: [
						{
							model: Students,
							as: 'student',
							attributes: { exclude: ['password'] },
						},
					],
				},
			],
			where: { id },
		});
		return data?.dataValues;
	},
	async deleteAttendance(id) {
		await StudentAttendance.destroy({
			where: {
				id,
			},
		});
	},

	async updateStudentsAttendance(StudentsAttendance, id) {
		await StudentsAttendances.update(
			{ state: StudentsAttendance.state, reason: StudentsAttendance.reason },
			{
				where: {
					id: id,
				},
			},
		);
	},
};
