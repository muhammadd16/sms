const express = require('express');
const router = express.Router();
const controller = require('./controller');
const validations = require('./validation');
const tokenParser = require('../../../middlewares/token-parser');
const { roles, canAccess } = require('../../../middlewares/permissions');

router.get(
	'/',
	tokenParser,
	canAccess([roles.manager, roles.teacher]),
	controller.getStudentsAttendance,
);
router.get(
	'/:id',
	tokenParser,
	canAccess([roles.manager, roles.teacher]),
	controller.getAttendanceById,
);
router.put(
	'/:id',
	tokenParser,
	canAccess([roles.manager, roles.teacher]),
	controller.updateStudentsAttendance,
);
router.post(
	'/',
	tokenParser,
	canAccess([roles.manager, roles.teacher]),
	validations.createStudentAttendance,
	controller.createStudentsAttendance,
);
router.get(
	'/attendances/:studentId',
	tokenParser,
	canAccess([roles.manager, roles.teacher, roles.parent, roles.student]),
	controller.getStudentsAttendanceByStudentId,
);
router.delete(
	'/:attendanceId',
	canAccess([roles.manager, roles.teacher]),
	tokenParser,
	controller.deleteAttendance,
);

module.exports = router;
