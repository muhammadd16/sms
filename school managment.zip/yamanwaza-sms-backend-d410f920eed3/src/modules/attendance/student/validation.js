const { body } = require('express-validator');
const model = require('./model');
module.exports = {
	createStudentAttendance: [body('classId').isInt(), body('sectionId').isInt()],
};
