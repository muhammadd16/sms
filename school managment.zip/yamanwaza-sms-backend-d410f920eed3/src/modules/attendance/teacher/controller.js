const express = require('express');
const { ErrorHandler } = require('../../../utils/error');
const { validationResult, body } = require('express-validator');
const { StatusCodes } = require('http-status-codes');
const model = require('./model');
const { defaults } = require('../../../utils/config');

module.exports = {
	async createTeachersAttendance(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let schoolId = req.body.__user.school.id;
				let body = req.body;
				await model.createTeachersAttendance(body, schoolId);
				res.__send(StatusCodes.CREATED);
			} catch (err) {
				next(err);
			}
		}
	},

	async getTeachersAttendance(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let schoolId = req.body.__user.school.id;
				//let studentId = +req.params['studentId'];
				let limit = +req.query['limit'] || defaults.limit;
				let offset = +req.query['offset'] || defaults.offset;

				let data = await model.getTeachersAttendance(schoolId, { limit, offset });
				res.__send(StatusCodes.OK, data);
			} catch (err) {
				next(err);
			}
		}
	},
	async getTeachersAttendance(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let schoolId = req.body.__user.school.id;
				//let studentId = +req.params['studentId'];
				let limit = +req.query['limit'] || defaults.limit;
				let offset = +req.query['offset'] || defaults.offset;
				let data = await model.getTeachersAttendance(schoolId, { limit, offset });
				res.__send(StatusCodes.OK, data);
			} catch (err) {
				next(err);
			}
		}
	},

	async getAttendanceById(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let schoolId = req.body.__user.school.id;
				let id = +req.params['id'];
				let data = await model.getTeachersAttendanceById(schoolId, id);
				res.__send(StatusCodes.OK, data);
			} catch (err) {
				next(err);
			}
		}
	},

	async updateTeachersAttendance(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let TeachersAttendance = req.body.TeachersAttendance[0].teachers;
				for (let i = 0; i < TeachersAttendance.length; i++)
					await model.updateTeachersAttendance(
						TeachersAttendance[i],
						TeachersAttendance[i].teacherId,
					);
				res.__send(StatusCodes.OK);
			} catch (err) {
				next(err);
			}
		}
	},
	async getTeachersAttendanceByTeacherId(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				//let schoolId = req.body.__user.school.id;
				let teacherId = +req.params['teacherId'];
				const tenDaysAgo = new Date(new Date().setDate(new Date().getDate() - 10));
				let from = req.query['from'] || tenDaysAgo;
				let to = req.query['to'] || new Date();
				let data = await model.getTeachersAttendanceByTeacherId(teacherId, from, to);
				res.__send(StatusCodes.OK, data);
			} catch (err) {
				next(err);
			}
		}
	},
};
