const TeachersAttendance = require('../../../models/teacher-attendance');
const TeachersAttendances = require('../../../models/teacher-attendances');
const Teachers = require('../../../models/teachers');
const { Op } = require('sequelize');

module.exports = {
	async createTeachersAttendance(data, schoolId) {
		data.schoolId = schoolId;
		const att = await TeachersAttendance.create(data, {
			include: [
				{
					model: TeachersAttendances,
					as: 'teachers',
				},
			],
		});
		return att.dataValues;
	},

	async getTeachersAttendance(schoolId, { limit, offset }, filters = {}) {
		const data = await TeachersAttendance.findAndCountAll({
			where: { schoolId, ...filters },
			limit,
			offset,
			include: [
				{
					model: TeachersAttendances,
					as: 'teachers',
				},
			],
		});
		return data;
	},

	async getTeachersAttendanceById(id) {
		const data = await TeachersAttendance.findOne({
			include: [
				{
					model: TeachersAttendances,
					as: 'teachers',
					include: [
						{
							model: Teachers,
							as: 'teacher',
							attributes: { exclude: ['password'] },
						},
					],
				},
			],
			where: { id },
		});
		return data?.dataValues;
	},

	async updateTeachersAttendance(TeachersAttendance, id) {
		await TeachersAttendances.update(
			{ state: TeachersAttendance.state, reason: TeachersAttendance.reason },
			{
				where: {
					id: id,
				},
			},
		);
	},

	async getTeachersAttendanceByTeacherId(teacherId, from, to) {
		const data = await TeachersAttendances.findAll({
			where: { teacherId },
			include: [
				{
					model: TeachersAttendance,
					as: 'attendance',
					where: {
						date: {
							[Op.between]: [from, to],
						},
					},
				},
			],
		});
		return data;
	},
};
