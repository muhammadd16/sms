const express = require('express');
const router = express.Router();
const controller = require('./controller');
const validations = require('./validation');
const tokenParser = require('../../../middlewares/token-parser');
const { roles, canAccess } = require('../../../middlewares/permissions');

router.get('/', tokenParser, canAccess([roles.manager]), controller.getTeachersAttendance);
router.get('/:id', tokenParser, canAccess([roles.manager]), controller.getAttendanceById);
router.post(
	'/',
	tokenParser,
	canAccess([roles.manager]),
	validations.createTeachersAttendance,
	controller.createTeachersAttendance,
);
router.put('/:id', tokenParser, canAccess([roles.manager]), controller.updateTeachersAttendance);
router.get(
	'/attendances/:teacherId',
	tokenParser,
	canAccess([roles.manager, roles.teacher]),
	controller.getTeachersAttendanceByTeacherId,
);

module.exports = router;
