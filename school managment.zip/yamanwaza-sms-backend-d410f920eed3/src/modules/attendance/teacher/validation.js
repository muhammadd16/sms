const { body } = require('express-validator');
const model = require('./model');
module.exports = {
	createTeachersAttendance: [],
};
