const express = require('express');
const AuthModel = require('./model');
const { ErrorHandler } = require('../../utils/error');
const { sendMail } = require('../../services/mailer');
const jwt = require('jsonwebtoken');
const { validationResult } = require('express-validator');
const { StatusCodes } = require('http-status-codes');
module.exports = {
	async login(req, res, next) {
		try {
			const user = await AuthModel.findByEmail(req.body.email);
			if (user && user.password == req.body.password) {
				delete user.password;
				var token = jwt.sign({ ...user }, process.env.TOKEN_SECRET, {
					expiresIn: '2d',
				});
				res.__send(StatusCodes.OK, { token, user });
			} else {
				next(new ErrorHandler(StatusCodes.NOT_FOUND, 'Invalid Email Or Password'));
			}
		} catch (err) {
			next(err);
		}
	},

	async signUp(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Validation Error', errors.array()));
		}
		try {
			const user = await AuthModel.findByEmail(req.body.email);
			if (user) {
				return next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Email Already Exist'));
			} else {
				const user = await AuthModel.create(req.body);
				let token = jwt.sign({ id: user.id, email: user.email }, process.env.TOKEN_SECRET, {
					expiresIn: '2d',
				});
				let url = `${process.env.FRONT_DOMAIN}/verify-account/${token}`;
				sendMail(user.email, 'Verify Your Account', `click here to verify your account ${url}`);
				res.__send(StatusCodes.CREATED);
			}
		} catch (err) {
			next(err);
		}
	},

	async forgetPassword(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		}
		try {
			let email = req.body.email;
			const user = AuthModel.findByEmail(email);
			if (!user) {
				res.send('OK');
				return;
			}
			let token = jwt.sign({ email }, process.env.TOKEN_SECRET, {
				expiresIn: '2d',
			});
			let resetUrl = `${process.env.FRONT_DOMAIN}/reset-password/${token}`;
			sendMail(email, 'Reset Your Password', `click here to reset your password ${resetUrl}`);
			res.send('OK');
		} catch (err) {
			next(err);
		}
	},

	async verifyAccount(req, res, next) {
		try {
			let token = req.body.token;
			jwt.verify(token, process.env.TOKEN_SECRET, async (err, data) => {
				if (err) {
					next(
						new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Validation Error', [
							'Token Expired',
						]),
					);
				} else {
					await AuthModel.setVerify(data.id);
					res.__send(StatusCodes.OK);
				}
			});
		} catch (err) {
			next(err);
		}
	},

	async resetPassword(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Validation Error', errors.array()));
		}
		try {
			let token = req.body.token;
			jwt.verify(token, process.env.TOKEN_SECRET, async (err, data) => {
				if (err) {
					next(
						new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Validation Error', [
							'Token Expired',
						]),
					);
				} else {
					let password = req.body.password;
					let email = data.email;
					let user = await AuthModel.findByEmail(email);
					if (!user) {
						throw new ErrorHandler(StatusCodes.NOT_FOUND, 'Validation Error');
					}
					await AuthModel.updatePassword(email, password);
					res.__send(StatusCodes.OK);
				}
			});
		} catch (err) {
			next(err);
		}
	},
};
