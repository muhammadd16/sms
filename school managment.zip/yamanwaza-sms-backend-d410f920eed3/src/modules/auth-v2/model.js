const Managers = require('../../models/managers');
const Teachers = require('../../models/teachers');
const Students = require('../../models/students');
const Parents = require('../../models/parents');
const Schools = require('../../models/schools');
const Classes = require('../../models/classes');
const Sections = require('../../models/sections');

const { getRoleFromEmail } = require('../../utils/global');

module.exports = {
	async findByEmail(email) {
		let role = getRoleFromEmail(email);
		let user = null;
		if (role == 'MANAGER') {
			user = await Managers.findOne({
				where: { email },
				include: { model: Schools, as: 'school' },
			});
		} else if (role == 'TEACHER') {
			user = await Teachers.findOne({
				where: { email },
				include: { model: Schools, as: 'school' },
			});
		} else if (role == 'STUDENT') {
			user = await Students.findOne({
				where: { email },
				include: [
					{ model: Schools, as: 'school' },
					{ model: Classes, as: 'class' },
					{ model: Sections, as: 'section' },
				],
			});
		} else if (role == 'PARENT') {
			user = await Parents.findOne({
				where: { email },
				include: [
					{ model: Schools, as: 'school' },
					{ model: Students, as: 'child', attributes: ['id', 'classId', 'sectionId'] },
				],
			});
		}
		if (user) {
			user = user.dataValues;
			user.role = role;
		}
		return user;
	},
	async create(body) {
		let manager = await Managers.create(body);
		return manager.dataValues;
	},

	async setVerify(id) {
		await Managers.update({ isVerified: true }, { where: { id } });
	},

	async updatePassword(email, password) {
		let role = getRoleFromEmail(email);
		if (role == 'MANAGER') {
			await Managers.update({ password }, { where: { email } });
		} else if (role == 'TEACHER') {
			await Teachers.update({ password }, { where: { email } });
		} else if (role == 'STUDENT') {
			await Students.update({ password }, { where: { email } });
		}
	},
};
