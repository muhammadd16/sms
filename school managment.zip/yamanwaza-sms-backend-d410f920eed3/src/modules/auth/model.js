const db = require('../../services/db');
const SchoolModel = require('../school-management/model');
module.exports = {
	async findByEmail(email) {
		let table = email.startsWith('teacher' && email.endsWith('@e-cademy.edu'))
			? 'Teachers'
			: email.startsWith('student' && email.endsWith('@e-cademy.edu'))
			? 'Students'
			: 'Managers';
		let results, res;
		if (table != 'Managers') {
			results = await db.query(`SELECT * FROM ${table} WHERE ${table}.email = ? `, [email]);
			if (!results || !results.length) return;
			res = results[0];
			res.school = await SchoolModel.getSchoolById(res.schoolId);
			res.role = table == 'Teachers' ? 'TEACHER' : 'STUDENT';
		} else {
			results = await db.query(`SELECT * FROM ${table} WHERE ${table}.email = ? `, [email]);
			if (!results || !results.length) return;
			res = results[0];
			res.school = await SchoolModel.getSchoolByManager(res.id);
			res.role = 'MANAGER';
		}
		return res;
	},

	async setVerify(email) {
		await db.query('UPDATE Managers SET isVerified = ? WHERE email = ?', [1, email]);
	},

	async updatePassword(email, password) {
		await db.query('UPDATE Managers SET password = ? WHERE email = ?', [password, email]);
	},

	async create(body) {
		var sql = `INSERT INTO Managers 
            (
                email, password, firstName, lastName, gender, picture
            )
            VALUES
            (
                ?, ?, ?, ?, ?, ?
            )`;
		var email = body.email;
		var password = body.password;
		var firstName = body.firstName;
		var lastName = body.lastName;
		var gender = body.gender;
		var picture = body.picture || '';
		let values = [email, password, firstName, lastName, gender, picture];
		await db.query(sql, values);
	},
};
