const express = require('express');
const router = express.Router();

const AuthController = require('./controller');
const AuthValidations = require('./validations');


router.post('/login', AuthController.login);
router.post('/sign-up', AuthValidations.signUp, AuthController.signUp);
router.post('/forget-password', AuthValidations.forgetPassword, AuthController.forgetPassword);
router.post('/reset-password', AuthValidations.resetPassword, AuthController.resetPassword);
router.post('/verify', AuthController.verifyAccount);

module.exports = router;
