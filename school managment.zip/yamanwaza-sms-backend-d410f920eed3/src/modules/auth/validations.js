const { body } = require('express-validator');
const AuthModel = require('./model');

module.exports = {
	forgetPassword: [body('email').isEmail()],
	resetPassword: [body('password').isLength({ min: 8 })],
	signUp: [
		body('email').isEmail(),
		body('password').isLength({ min: 8 }),
		body('firstName').notEmpty(),
		body('lastName').notEmpty(),
		body('gender').isIn(['male', 'female']),
	],
};
