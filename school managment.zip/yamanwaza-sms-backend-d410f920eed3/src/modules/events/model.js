const Events = require('../../models/events');
const Classes = require('../../models/classes');
const Sections = require('../../models/sections');

const { Op } = require('sequelize');
module.exports = {
	async getEvents(schoolId, { limit, offset }, filters = {}) {
		const data = await Events.findAndCountAll({
			where: {
				schoolId,
				...filters,
			},
			limit,
			offset,
			include: [
				{
					model: Classes,
					as: 'class',
				},
				{
					model: Sections,
					as: 'section',
				},
			],
		});
		return data;
	},
	async getEventById(id) {
		const event = await Events.findOne({
			where: { id },
			include: [
				{
					model: Classes,
					as: 'class',
				},
				{
					model: Sections,
					as: 'section',
				},
			],
		});
		return event?.dataValues;
	},
	async createEvent(schoolId, body) {
		const event = await Events.create({
			...body,
			schoolId,
		});
		return event;
	},
	async getIncomingEvents(schoolId) {
		let data = await Events.findAll({
			where: {
				schoolId,
				date: {
					[Op.gte]: new Date(),
				},
			},
			include: [
				{
					model: Classes,
					as: 'class',
				},
				{
					model: Sections,
					as: 'section',
				},
			],
		});
		return data;
	},
	async editEvent(id, body) {
		let data = await Events.update(body, { where: { id } });
		return data;
	},
	async deleteEvent(id) {
		return await Events.destroy({ where: { id } });
	},
};
