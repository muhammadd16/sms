const express = require('express');
const router = express.Router();

const controller = require('./controller');
const validations = require('./validations');
const tokenParser = require('../../middlewares/token-parser');
const { roles, canAccess } = require('../../../src/middlewares/permissions');

router.get('/', tokenParser, canAccess([roles.manager, roles.teacher]), controller.getEvents);
router.get(
	'/upcoming',
	tokenParser,
	canAccess([roles.manager, roles.teacher, roles.parent, roles.student]),
	controller.getIncomingEvents,
);
router.post(
	'/',
	tokenParser,
	canAccess([roles.manager, roles.teacher]),
	validations.createEvent,
	controller.createEvent,
);
router.put(
	'/:id',
	tokenParser,
	canAccess([roles.manager, roles.teacher]),
	validations.editEvent,
	controller.editEvent,
);
router.get('/:id', tokenParser, canAccess([roles.manager, roles.teacher]), controller.getEventById);
router.delete(
	'/:id',
	tokenParser,
	canAccess([roles.manager, roles.teacher]),
	controller.deleteEvent,
);

module.exports = router;
