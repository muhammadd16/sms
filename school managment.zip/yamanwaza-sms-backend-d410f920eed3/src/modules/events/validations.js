const { body } = require('express-validator');

module.exports = {
	createEvent: [
		body('classId').isInt(),
		body('sectionId').isInt(),
		body('name').exists(),
		body('type').isIn(['exam', 'holiday', 'trip', 'other']),
		body('date').custom((date) => {
			return !isNaN(Date.parse(date));
		}),
	],
	editEvent: [
		body('classId').isInt(),
		body('sectionId').isInt(),
		body('name').exists(),
		body('type').isIn(['exam', 'holiday', 'trip', 'other']),
		body('date').custom((date) => {
			return !isNaN(Date.parse(date));
		}),
	],
};
