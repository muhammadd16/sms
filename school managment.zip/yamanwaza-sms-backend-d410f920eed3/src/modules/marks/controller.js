const express = require('express');
const { ErrorHandler } = require('../../utils/error');
const { validationResult, body } = require('express-validator');
const { StatusCodes } = require('http-status-codes');
const model = require('./model');
const { defaults } = require('../../utils/config');

module.exports = {
	async getQuizzes(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let schoolId = req.body.__user.school.id;
				let limit = +req.query['limit'] || defaults.limit;
				let offset = +req.query['offset'] || defaults.offset;
				let name = +req.query['name'];
				let filters = {};
				if (name) filters.name = name;
				let data = await model.getQuizzes(schoolId, { limit, offset }, filters);
				res.__send(StatusCodes.OK, data);
			} catch (err) {
				next(err);
			}
		}
	},
	async getQuizById(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let id = +req.params['id'];
				let data = await model.getQuizById(id);
				res.__send(StatusCodes.OK, data);
			} catch (err) {
				next(err);
			}
		}
	},
	async createQuiz(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let schoolId = req.body.__user.school.id;
				let body = req.body;
				let data = await model.createQuiz(schoolId, body);
				res.__send(StatusCodes.CREATED, data);
			} catch (err) {
				next(err);
			}
		}
	},
	async editQuiz(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let id = +req.params['id'];
				let body = req.body;
				let data = await model.editQuiz(id, body);
				await Promise.all(
					body.marks.map(async (mark) => {
						return await model.editMark(mark.id, mark);
					}),
				);
				res.__send(StatusCodes.OK, data);
			} catch (err) {
				next(err);
			}
		}
	},
	async deleteQuiz(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let id = +req.params['id'];
				await model.deleteQuiz(id);
				res.__send(StatusCodes.OK);
			} catch (err) {
				next(err);
			}
		}
	},
	async getStudentMarks(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let id = +req.params['id'];
				let data = await model.getStudentMarks(id);
				res.__send(StatusCodes.OK, data);
			} catch (err) {
				next(err);
			}
		}
	},
};
