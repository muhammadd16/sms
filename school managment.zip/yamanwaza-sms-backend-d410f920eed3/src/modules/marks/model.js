const Quizzes = require('../../models/quizzes');
const StudentsMarks = require('../../models/students-marks');
const Subjects = require('../../models/subjects');
const Students = require('../../models/students');

module.exports = {
	async getQuizzes(schoolId, { limit, offset }, filters = {}) {
		const data = await Quizzes.findAndCountAll({
			where: { schoolId, ...filters },
			limit,
			offset,
		});
		return data;
	},
	async createQuiz(schoolId, data) {
		data.schoolId = schoolId;
		const quiz = await Quizzes.create(data, {
			include: [
				{
					model: StudentsMarks,
					as: 'marks',
				},
			],
		});
		return quiz.dataValues;
	},
	async getQuizById(id) {
		let data = await Quizzes.findOne({
			where: { id },
			include: [
				{
					model: StudentsMarks,
					as: 'marks',
					include: [{ model: Students, as: 'student', attributes: { exclude: ['password'] } }],
				},
			],
		});
		data = data?.dataValues;
		return data;
	},
	async editQuiz(id, data) {
		await Quizzes.update(data, {
			where: { id },
			include: [
				{
					model: StudentsMarks,
					as: 'marks',
				},
			],
		});
	},
	async editMark(id, data) {
		await StudentsMarks.update(data, {
			where: { id },
		});
	},
	async deleteQuiz(id) {
		await Quizzes.destroy({ where: { id } });
	},
	async getStudentMarks(studentId) {
		let data = await StudentsMarks.findAll({
			where: { studentId },
			include: [
				{
					model: Quizzes,
					as: 'quiz',
					include: [
						{
							model: Subjects,
							as: 'subject',
						},
					],
				},
			],
		});
		data = data.reduce((ac, cur) => {
			cur = cur.dataValues;
			cur.quiz = cur.quiz.dataValues;
			cur.quiz.subject = cur.quiz.subject.dataValues;

			if (!ac.some((subject) => subject.id === cur.quiz.subject.id)) {
				cur.quiz.subject.quizzes = [];
				ac.push({ ...cur.quiz.subject });
			}
			let subject = ac.find((subject) => subject.id === cur.quiz.subject.id);
			subject.quizzes.push({
				id: cur.quiz.id,
				name: cur.quiz.name,
				mark: cur.mark,
				fullMark: cur.quiz.fullMark,
				successMark: cur.quiz.successMark,
			});
			return ac;
		}, []);
		let subjects = data.map((subject) => {
			return {
				...subject,
				avg:
					subject.quizzes.reduce((ac, cur) => {
						let percent = (cur.mark / cur.fullMark) * 100;
						return ac + percent;
					}, 0) / subject.quizzes.length,
			};
		});
		return { subjects };
	},
};
