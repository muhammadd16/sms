const express = require('express');
const router = express.Router();
const controller = require('./controller');
const validations = require('./validations');
const tokenParser = require('../../middlewares/token-parser');
const { roles, canAccess } = require('../../../src/middlewares/permissions');

router.get(
	'/quizzes',
	tokenParser,
	canAccess([roles.manager, roles.teacher]),

	controller.getQuizzes,
);
router.get(
	'/quizzes/:id',
	tokenParser,
	canAccess([roles.manager, roles.teacher]),
	controller.getQuizById,
);
router.post(
	'/quizzes',
	tokenParser,
	canAccess([roles.manager, roles.teacher]),
	validations.createQuiz,
	controller.createQuiz,
);
router.put(
	'/quizzes/:id',
	tokenParser,
	canAccess([roles.manager, roles.teacher]),
	controller.editQuiz,
);

router.delete(
	'/quizzes/:id',
	canAccess([roles.manager, roles.teacher]),
	tokenParser,
	controller.deleteQuiz,
);

router.get(
	'/student/:id',
	tokenParser,
	canAccess([roles.manager, roles.teacher, roles.student, roles.parent]),
	controller.getStudentMarks,
);

module.exports = router;
