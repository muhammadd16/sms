const { body } = require('express-validator');
const model = require('./model');
module.exports = {
	createQuiz: [
		body('subjectId').isInt(),
		body('name').notEmpty(),
		body('fullMark').isInt(),
		body('successMark').isInt(),
		body('marks').isArray(),
		body('marks.*.studentId').isInt(),
		body('marks.*.mark').isInt(),
	],
};
