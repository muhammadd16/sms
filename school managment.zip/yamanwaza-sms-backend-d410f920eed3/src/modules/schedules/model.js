const Schedules = require('../../models/schedules');
const SchedulePeriods = require('../../models/schedule-periods');
const Subjects = require('../../models/subjects');
const Classes = require('../../models/classes');
const Sections = require('../../models/sections');
const Teachers = require('../../models/teachers');

function mappingScheduleById(data) {
	return data.reduce((ac, cur) => {
		cur = cur.dataValues;
		cur.subject = cur.subject.dataValues;
		cur.teacher = cur.teacher.dataValues;
		cur.schedule = cur.schedule.dataValues;
		delete cur.teacher.email;
		delete cur.teacher.password;
		if (!ac[cur.day]) ac[cur.day] = [];
		ac[cur.day].push({
			id: cur.id,
			period: cur.period,
			class: cur.schedule.class,
			section: cur.schedule.section,
			subject: cur.subject,
			teacher: cur.teacher,
		});
		return ac;
	}, {});
}

module.exports = {
	async getSchedules(schoolId, { limit, offset }, filters = {}) {
		const data = await Schedules.findAndCountAll({
			where: {
				schoolId,
				...filters,
			},
			limit,
			offset,
			include: [
				{
					model: Classes,
					as: 'class',
				},
				{
					model: Sections,
					as: 'section',
				},
			],
		});
		return data;
	},
	async getScheduleById(scheduleId) {
		const data = await SchedulePeriods.findAll({
			where: { scheduleId },
			include: [
				{ model: Subjects, as: 'subject' },
				{ model: Teachers, as: 'teacher' },
				{
					model: Schedules,
					as: 'schedule',
					include: [
						{
							model: Classes,
							as: 'class',
						},
						{
							model: Sections,
							as: 'section',
						},
					],
				},
			],
		});
		return mappingScheduleById(data);
	},
	async getScheduleBySectionId(sectionId) {
		let scheduleId = await Schedules.findOne({ where: { sectionId } });
		scheduleId = scheduleId?.dataValues?.id;
		if (!scheduleId) return {};
		const data = await SchedulePeriods.findAll({
			where: { scheduleId },
			include: [
				{ model: Subjects, as: 'subject' },
				{ model: Teachers, as: 'teacher' },
				{
					model: Schedules,
					as: 'schedule',
					include: [
						{
							model: Classes,
							as: 'class',
						},
						{
							model: Sections,
							as: 'section',
						},
					],
				},
			],
		});
		return mappingScheduleById(data);
	},
	async createSchedule(schoolId, bodyData) {
		bodyData.schoolId = schoolId;
		const data = await Schedules.create(bodyData, {
			include: [{ model: SchedulePeriods, as: 'periods' }],
		});
		return data.dataValues;
	},
	async addSchedulePeriod(scheduleId, period) {
		await SchedulePeriods.create({
			...period,
			scheduleId,
		});
	},
	async editSchedule(id, bodyData) {
		const data = await Schedules.update(bodyData, {
			where: { id },
			include: [{ model: SchedulePeriods, as: 'periods' }],
		});
	},
	async editSchedulePeriod(id, data) {
		await SchedulePeriods.update(data, {
			where: { id },
		});
	},
	async deleteSchedule(id) {
		await Schedules.destroy({
			where: { id },
		});
	},
	async getTeacherSchedule(teacherId) {
		let data = await SchedulePeriods.findAll({
			where: { teacherId },
			include: [
				{ model: Subjects, as: 'subject' },
				{
					model: Schedules,
					as: 'schedule',
					include: [
						{
							model: Classes,
							as: 'class',
						},
						{
							model: Sections,
							as: 'section',
						},
					],
				},
			],
		});
		return data.reduce((ac, cur) => {
			cur = cur.dataValues;
			cur.subject = cur.subject.dataValues;
			cur.schedule = cur.schedule.dataValues;

			if (!ac[cur.day]) ac[cur.day] = [];
			ac[cur.day].push({
				period: cur.period,
				class: cur.schedule.class,
				section: cur.schedule.section,
				subject: cur.subject,
			});
			return ac;
		}, {});
	},
	async getAllTeachersPeriods(schoolId) {
		let data = await Schedules.findAll({
			where: { schoolId },
			include: [
				{
					model: SchedulePeriods,
					as: 'periods',
				},
			],
		});
		const res = data.reduce((ac, cur) => {
			cur = cur.dataValues;
			cur.periods.forEach((period) => {
				period = period.dataValues;
				if (!ac[period.teacherId]) ac[period.teacherId] = [];
				ac[period.teacherId].push(period);
			});
			return ac;
		}, {});
		console.log(res);
		return res;
	},
	async getSectionsHasSchedule(schoolId) {
		let data = await Schedules.findAll({ where: { schoolId } });
		return data.reduce((ac, cur) => {
			cur = cur.dataValues;
			if (!ac.some((id) => id == cur.sectionId)) {
				ac.push(cur.sectionId);
			}
			return ac;
		}, []);
	},
};
