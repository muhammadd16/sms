const express = require('express');
const router = express.Router();
const controller = require('./controller');
const validations = require('./validations');
const tokenParser = require('../../middlewares/token-parser');
const { roles, canAccess } = require('../../../src/middlewares/permissions');

router.get('/', tokenParser, canAccess([roles.manager]), controller.getSchedules);
router.post(
	'/',
	tokenParser,
	canAccess([roles.manager]),
	validations.createSchedule,
	controller.createSchedule,
);
router.put('/:id/periods', tokenParser, canAccess([roles.manager]), controller.editSchedulePeriods);
router.delete('/:id', tokenParser, canAccess([roles.manager]), controller.deleteSchedule);
router.get(
	'/teachers/all',
	tokenParser,
	canAccess([roles.manager, roles.teacher]),
	controller.getAllTeachersPeriods,
);
router.get(
	'/teacher/:id',
	tokenParser,
	canAccess([roles.manager, roles.teacher]),
	controller.getTeacherSchedule,
);
router.get(
	'/sections',
	tokenParser,
	canAccess([roles.manager, roles.teacher, roles.student, roles.parent]),
	controller.getSectionsHasSchedule,
);
router.get(
	'/sections/:id',
	tokenParser,
	canAccess([roles.manager, roles.teacher, roles.student, roles.parent]),
	controller.getScheduleBySectionId,
);
router.get(
	'/:id',
	tokenParser,
	canAccess([roles.manager, roles.teacher, roles.student, roles.parent]),
	controller.getScheduleById,
);

module.exports = router;
