const { body } = require('express-validator');
const model = require('./model');
module.exports = {
	createSchedule: [
		body('classId').isInt(),
		body('sectionId').isInt(),
		body('periods.*.subjectId').isInt(),
		body('periods.*.teacherId').isInt(),
		body('periods.*.period').isInt(),
		body('periods.*.day').isIn([
			'saturday',
			'sunday',
			'monday',
			'tuesday',
			'wednesday',
			'thursday',
			'friday',
		]),
		// TODO: add validation that check if there is schedule already created for sectionId section
		// TODO: check overlapping teachers in periods
	],
	editSchedule: [
		body('periods').isArray(),
		body('periods.*.id').isInt(),
		body('periods.*.teacherId').isInt(),
		body('periods.*.subjectId').isInt(),
		// TODO: check overlapping teachers in periods
	],
};
