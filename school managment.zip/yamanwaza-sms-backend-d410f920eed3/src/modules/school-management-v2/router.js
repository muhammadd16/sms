const express = require('express');
const app = express();
const School = require('./school/router');
const Teacher = require('./teacher/router');
const Student = require('./student/router');

app.use('/school', School);
app.use('/teacher', Teacher);
app.use('/student', Student);

module.exports = app;
