const express = require('express');
const router = express.Router();
const controller = require('./controller');
const uploadImage = require('../../../middlewares/upload-image');
const validation = require('./validation');
const tokenParser = require('../../../middlewares/token-parser');
const formDataParser = require('../../../middlewares/form-data-parser');

// // Create School
router.post('/', tokenParser, formDataParser, validation.createSchool, controller.createSchool);

// // Update School
router.put('/', tokenParser, formDataParser, validation.updateSchool, controller.updateSchool);

// Get Classes
router.get('/class', tokenParser, controller.getClasses);

// Create Classes
router.post('/class', tokenParser, validation.createClass, controller.createClass);

// Update Classes
router.put('/class', tokenParser, validation.updateClasses, controller.updateClasses);

// Delete Classes
router.delete('/class', tokenParser, controller.deleteClasses);

// Get Sections By Class Id
router.get('/section/:classId', tokenParser, controller.getSectionsByClassId);

// Create Sections
router.post('/section', tokenParser, validation.createSections, controller.createSections);

// Update Sections
router.put('/section', tokenParser, validation.updateSections, controller.updateSections);

// Delete Sections
router.delete('/section', tokenParser, controller.deleteSections);

// Get Subjects By Class Id
router.get('/subject/:classId', tokenParser, controller.getSubjectsByClassId);

// Create Subjects
router.post('/subject', tokenParser, validation.createSections, controller.createSubjects);

// Update Subjects
router.put('/subject', tokenParser, validation.updateٍSubjects, controller.updateSubjects);

// Delete Subjects
router.delete('/subject', tokenParser, controller.deleteSubjects);
/////////////////////////////
router.get('/get-school', controller.getSchool);

module.exports = router;
