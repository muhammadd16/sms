const express = require('express');
const { ErrorHandler } = require('../../../utils/error');
const { validationResult, body } = require('express-validator');
const { StatusCodes } = require('http-status-codes');
const model = require('./model');
const { defaults } = require('../../../utils/config');
const getTotalRecords = require('../../../utils/getTotalRecords');

module.exports = {
	async createStudent(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				await model.createStudent(req.body);
				res.__send(StatusCodes.CREATED);
			} catch (err) {
				next(err);
			}
		}
	},
	async getStudents(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let schoolId = req.body.__user.school.id;

				let limit = +req.query['limit'] || defaults.limit;
				let offset = +req.query['offset'] || defaults.offset;

				let data = await model.getStudent(limit, offset, schoolId);
				let totalRecords = await getTotalRecords('Students', schoolId);

				res.__send(StatusCodes.OK, { data, totalRecords });
			} catch (err) {
				next(err);
			}
		}
	},
	async getStudentById(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let id = +req.params['id'];

				let data = await model.getStudentById(id);

				res.__send(StatusCodes.OK, data);
			} catch (err) {
				next(err);
			}
		}
	},
	async deleteStudent(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let id = +req.params['id'];
				let schoolId = req.body.__user.school.id;

				await model.deleteStudent(id, schoolId);
				res.__send(StatusCodes.OK);
			} catch (err) {
				next(err);
			}
		}
	},
	async updateStudent(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let student = req.body;
				let id = +req.params['id'];
				let schoolId = req.body.__user.school.id;
				await model.updateStudents(student, id, schoolId);
				res.__send(StatusCodes.OK);
			} catch (err) {
				next(err);
			}
		}
	},
};
