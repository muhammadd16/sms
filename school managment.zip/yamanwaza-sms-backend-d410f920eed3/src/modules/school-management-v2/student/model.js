const { request } = require('express');
const db = require('../../../services/db');
const getNextId = require('../../../utils/getNextId');
const { generatePassword } = require('../../../utils/global');

module.exports = {
	async createStudent(body) {
		let schoolId = body.__user.school.id;

		let serial = await getNextId('Students', schoolId);
		var sql = `INSERT INTO Students
		(
			id,fatherName, motherName, schoolId, classId , sectionId ,firstName , lastName ,gender , email, password ,picture
		)
		VALUES
		(
			?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
		)`;
		var fatherName = body.fatherName;
		var motherName = body.motherName;
		var gender = body.gender;
		var classId = body.classId;
		var sectionId = body.sectionId;
		var firstName = body.firstName;
		var lastName = body.lastName;
		var email = 'student-' + schoolId + '-' + id + '@e-cademy.edu';
		var password = generatePassword();
		var picture = body.picture;

		let values = [
			id,
			fatherName,
			motherName,
			schoolId,
			classId,
			sectionId,
			firstName,
			lastName,
			gender,
			email,
			password,
			picture,
		];
		await db.query(sql, values);
	},
	async getStudent(params, schoolId) {
		// Student.find({where:params});
		//var sql = `SELECT * FROM Students WHERE schoolId= ?  LIMIT ? OFFSET ? `;
		var sql = ` SELECT *  ,Schools.id AS schoolid,Classes.name AS className,Sections.name AS sectionName
		 FROM Students  AS ss 
		 JOIN Schools ON Schools.id = ss.schoolId
		 JOIN Classes ON Schools.id = Classes.schoolId
		 JOIN Sections ON  Classes.id = Sections.classId
		WHERE ss.schoolId= ?  LIMIT ? OFFSET ? `;

		let results = await db.query(sql, [schoolId, limit, offset]);
		return results;
	},
	async updateStudents(student, id, schoolId) {
		let query =
			'UPDATE Students SET fatherName = ?, motherName = ? ,classId = ?,sectionId = ?,firstName = ?,lastName =?, gender=?,email=? ,password=? ,picture=? WHERE id= ? AND schoolId = ? ';
		let values = [
			student.fatherName,
			student.motherName,
			student.classId,
			student.sectionId,
			student.firstName,
			student.lastName,
			student.gender,
			student.email,
			student.password,
			student.picture,
			id,
			schoolId,
		];
		await db.query(query, values);
	},
	async deleteStudent(id, schoolId) {
		let query = `DELETE FROM Students WHERE id = ? AND schoolId = ? `;
		await db.query(query, [id, schoolId]);
	},
	async getStudentById(id) {
		let sql = `SELECT * FROM Students WHERE id = ?`;
		let res = await db.query(sql, [id]);
		res = res && res.length ? res[0] : undefined;
		return res;
	},


};
