const express = require('express');
const router = express.Router();
const controller = require('./controller');
const uploadImage = require('../../../middlewares/upload-image');
const validation = require('./validation');
const tokenParser = require('../../../middlewares/token-parser');
const formDataParser = require('../../../middlewares/form-data-parser');

// Get Student By Id
router.get('/:id', controller.getStudentById);

// // Get Students List By Criteria
router.get('/', tokenParser, controller.getStudents);

// // Create Student
router.post('/', tokenParser, formDataParser, validation.createStudent, controller.createStudent);

// // Update Student
router.put('/:id', tokenParser, formDataParser, validation.createStudent, controller.updateStudent);

// // Delete Student
router.delete('/:id', tokenParser, controller.deleteStudent);

module.exports = router;
