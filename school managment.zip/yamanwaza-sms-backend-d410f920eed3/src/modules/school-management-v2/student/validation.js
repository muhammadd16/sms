const { body } = require('express-validator');
const model = require('./model');
module.exports = {
	createStudent: [
		body('fatherName').notEmpty(),
		body('motherName').notEmpty(),
		body('firstName').notEmpty(),
		body('lastName').notEmpty(),
		body('gender').isIn(['male', 'female']),
	],
};
