const express = require('express');
const { ErrorHandler } = require('../../../utils/error');
const { validationResult, body } = require('express-validator');
const { StatusCodes } = require('http-status-codes');
const model = require('./model');
const { defaults } = require('../../../utils/config');
const getTotalRecords = require('../../../utils/getTotalRecords');

module.exports = {
	async createTeacher(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				await model.createTeacher(req.body);
				res.__send(StatusCodes.CREATED);
			} catch (err) {
				next(err);
			}
		}
	},
	async getTeachers(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let schoolId = req.body.__user.school.id;

				let limit = +req.query['limit'] || defaults.limit;
				let offset = +req.query['offset'] || defaults.offset;

				let data = await model.getTeacher(schoolId, limit, offset);
				let totalRecords = await getTotalRecords('Teachers', schoolId);

				res.__send(StatusCodes.OK, { data, totalRecords });
			} catch (err) {
				next(err);
			}
		}
	},
	async getTeacherById(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let id = +req.params['id'];

				let data = await model.getTeacherById(id);

				res.__send(StatusCodes.OK, { data });
			} catch (err) {
				next(err);
			}
		}
	},
	async deleteTeacher(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let id = +req.params['id'];
				let schoolId = req.body.__user.school.id;

				await model.deleteTeacher(id, schoolId);
				res.__send(StatusCodes.OK);
			} catch (err) {
				next(err);
			}
		}
	},
	async updateTeacher(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let teacher = req.body;
				let schoolId = req.body.__user.school.id;
				let id = +req.params['id'];
				await model.updateTeacher(teacher, id, schoolId);
				res.__send(StatusCodes.OK);
			} catch (err) {
				next(err);
			}
		}
	},
};
