const { request } = require('express');
const db = require('../../../services/db');
const getNextId = require('../../../utils/getNextId');
const { generatePassword } = require('../../../utils/global');

module.exports = {
	async createTeacher(body) {
		var schoolId = body.__user.school.id;
		let id = await getNextId('Teachers', schoolId);

		var sql = ` 
		
		INSERT INTO Teachers
		(
			id,schoolId,firstName,lastName,picture,gender,email,password,grade
		)
		VALUES
		(
			?,?,?,?,?,?,?,?,?
		);
		 `;
		var firstName = body.firstName;
		var lastName = body.lastName;
		var gender = body.gender;
		var grade = body.grade;
		var email = 'teacher-' + schoolId + '-' + id + '@e-cademy.edu';
		var picture = body.picture;
		var password = generatePassword();
		console.log('school', schoolId, id);

		let values = [id, schoolId, firstName, lastName, picture, gender, email, password, grade];
		await db.query(sql, values);
	},
	async getTeacher(schoolId, limit, offset) {
		var sql = `SELECT * FROM Teachers WHERE schoolId = ? LIMIT ? OFFSET ? `;

		let results = await db.query(sql, [schoolId, limit, offset]);
		return results;
	},
	async updateTeacher(teacher, id, schoolId) {
		let query =
			'UPDATE Teachers SET grade = ?, firstName = ? ,lastName = ?,gender = ?,email = ?,password =?, picture=? WHERE id= ? AND schoolId = ? ';
		let values = [
			teacher.grade,
			teacher.firstName,
			teacher.lastName,
			teacher.gender,
			teacher.email,
			teacher.password,
			teacher.picture,
			id,
			schoolId,
		];
		await db.query(query, values);
	},
	async deleteTeacher(id, schoolId) {
		let query = `DELETE FROM Teachers WHERE id = ? AND schoolId = ? `;
		await db.query(query, [id, schoolId]);
	},
	async getTeacherById(id) {
		let sql = `SELECT * FROM Teachers WHERE id = ?`;
		let res = await db.query(sql, [id]);
		res = res && res.length ? res[0] : undefined;
		return res;
	},
};
