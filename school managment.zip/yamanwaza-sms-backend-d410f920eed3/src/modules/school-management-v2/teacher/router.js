const express = require('express');
const router = express.Router();
const controller = require('./controller');
const uploadImage = require('../../../middlewares/upload-image');
const validation = require('./validation');
const tokenParser = require('../../../middlewares/token-parser');
const formDataParser = require('../../../middlewares/form-data-parser');

// Get Teacher By Id
router.get('/:id', controller.getTeacherById);

// // Get Teachers List By Criteria
router.get('/', tokenParser, controller.getTeachers);

// // Create Teacher
router.post('/', tokenParser, formDataParser, validation.createTeacher, controller.createTeacher);

// // Update Teacher
router.put('/:id', tokenParser, formDataParser, validation.createTeacher, controller.updateTeacher);

// // Delete Teacher
router.delete('/:id', tokenParser, controller.deleteTeacher);

module.exports = router;
