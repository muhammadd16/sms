const { body } = require('express-validator');
const model = require('./model');
module.exports = {
	createTeacher: [
		body('firstName').notEmpty(),
		body('grade').notEmpty(),
		body('lastName').notEmpty(),
		body('gender').isIn(['male', 'female']),
	],
};
