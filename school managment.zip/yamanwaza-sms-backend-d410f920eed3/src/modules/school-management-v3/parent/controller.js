const express = require('express');
const { ErrorHandler } = require('../../../utils/error');
const { validationResult, body } = require('express-validator');
const { StatusCodes } = require('http-status-codes');
const model = require('./model');
const { defaults } = require('../../../utils/config');

module.exports = {
	async getParents(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let schoolId = req.body.__user.school.id;

				let limit = +req.query['limit'] || defaults.limit;
				let offset = +req.query['offset'] || defaults.offset;

				let data = await model.getParents(schoolId, { limit, offset });

				res.__send(StatusCodes.OK, data);
			} catch (err) {
				next(err);
			}
		}
	},
};
