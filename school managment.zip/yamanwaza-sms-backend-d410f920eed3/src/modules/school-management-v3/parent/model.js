const Parents = require('../../../models/parents');

module.exports = {
	async getParents(schoolId, { limit, offset }, filters = {}) {
		let data = await Parents.findAndCountAll({
			where: { ...filters, schoolId },
			limit,
			offset,
		});

		data.rows.forEach((parent) => {
			parent.dataValues.role = 'PARENT';
		});
		return data;
	},
};
