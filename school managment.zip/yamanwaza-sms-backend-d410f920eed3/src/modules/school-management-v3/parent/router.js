const express = require('express');
const router = express.Router();
const controller = require('./controller');
const validation = require('./validation');
const tokenParser = require('../../../middlewares/token-parser');
const formDataParser = require('../../../middlewares/form-data-parser');
const { roles, canAccess } = require('../../../middlewares/permissions');


// get parents list
router.get('/', tokenParser,
    canAccess([roles.manager]),
    controller.getParents);

module.exports = router;
