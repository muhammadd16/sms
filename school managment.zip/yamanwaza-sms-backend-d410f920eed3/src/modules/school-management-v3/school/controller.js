const express = require('express');
const { ErrorHandler } = require('../../../utils/error');
const { validationResult, body } = require('express-validator');
const { StatusCodes } = require('http-status-codes');
const model = require('./model');

module.exports = {
	async createSchool(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				await model.createSchool(req.body);
				res.__send(StatusCodes.CREATED);
			} catch (err) {
				next(err);
			}
		}
	},
	async createClass(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let schoolId = req.body.__user.school.id;

				let classes = req.body.classes;
				for (let i = 0; i < classes.length; i++) await model.createClass(classes[i], schoolId);
				res.__send(StatusCodes.CREATED);
			} catch (err) {
				next(err);
			}
		}
	},
	async createSections(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				// We Will Toke ClassId from section Object
				let sections = req.body.sections;
				for (let i = 0; i < sections.length; i++) await model.createSection(sections[i]);
				res.__send(StatusCodes.CREATED);
			} catch (err) {
				next(err);
			}
		}
	},
	async createSubjects(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let subjects = req.body.subjects;
				for (let i = 0; i < subjects.length; i++) await model.createSubject(subjects[i]);
				res.__send(StatusCodes.CREATED);
			} catch (err) {
				next(err);
			}
		}
	},
	async getClasses(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let schoolId = req.body.__user.school.id;

				let data = await model.getClasses(schoolId);

				res.__send(StatusCodes.OK, { data });
			} catch (err) {
				next(err);
			}
		}
	},
	async getSectionsByClassId(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let classId = +req.params['classId'];

				let data = await model.getSectionsByClassId(classId);

				res.__send(StatusCodes.OK, data);
			} catch (err) {
				next(err);
			}
		}
	},
	async getSubjectsByClassId(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let classId = +req.params['classId'];
				let data = await model.getSubjectsByClassId(classId);

				res.__send(StatusCodes.OK, data);
			} catch (err) {
				next(err);
			}
		}
	},

	async deleteClasses(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let classes = req.body.classes;
				for (let i = 0; i < classes.length; i++) await model.deleteClass(classes[i].id);
				res.__send(StatusCodes.OK);
			} catch (err) {
				next(err);
			}
		}
	},
	async deleteSections(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let sections = req.body.sections;

				for (let i = 0; i < sections.length; i++) await model.deleteSection(sections[i].id);
				res.__send(StatusCodes.OK);
			} catch (err) {
				next(err);
			}
		}
	},
	async deleteSubjects(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let subjects = req.body.subjects;

				for (let i = 0; i < subjects.length; i++) await model.deleteSubject(subjects[i].id);
				res.__send(StatusCodes.OK);
			} catch (err) {
				next(err);
			}
		}
	},
	async updateClasses(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let classes = req.body.classes;
				for (let i = 0; i < classes.length; i++)
					await model.updateClass(classes[i], classes[i].id);
				res.__send(StatusCodes.OK);
			} catch (err) {
				next(err);
			}
		}
	},
	async updateSubjects(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let subjects = req.body.subjects;
				for (let i = 0; i < subjects.length; i++)
					await model.updateSubject(subjects[i], subjects[i].id);
				res.__send(StatusCodes.OK);
			} catch (err) {
				next(err);
			}
		}
	},
	async updateSections(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let sections = req.body.sections;
				for (let i = 0; i < sections.length; i++)
					await model.updateSections(sections[i], sections[i].id);
				res.__send(StatusCodes.OK);
			} catch (err) {
				next(err);
			}
		}
	},
	async updateSchool(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let school = req.body;
				let schoolId = req.body.__user.school.id;

				await model.updateSchool(school, schoolId);
				res.__send(StatusCodes.OK);
			} catch (err) {
				next(err);
			}
		}
	},
	async getAllInfo(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let schoolId = req.body.__user.school.id;
				const data = await model.getAllSchoolInfo(schoolId);
				if (data) res.__send(StatusCodes.OK, data);
				else next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Invalid Data'));
			} catch (err) {
				next(err);
			}
		}
	},
};
