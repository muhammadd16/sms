const Schools = require('../../../models/schools');
const Classes = require('../../../models/classes');
const Sections = require('../../../models/sections');
const Subjects = require('../../../models/subjects');

module.exports = {
	async createSchool(body) {
		body.managerId = body.__user.id;
		let school = await Schools.create(body);
		return school.dataValues;
	},
	async createClass(body, schoolId) {
		let c = await Classes.create(
			{ ...body, schoolId },
			{
				include: [
					{
						model: Sections,
						as: 'sections',
					},
					{
						model: Subjects,
						as: 'subjects',
					},
				],
			},
		);
		return c.dataValues;
	},
	async createSection(body) {
		let section = await Sections.create(body);
		return section.dataValues;
	},
	async createSubject(body) {
		let subject = await Subjects.create(body);
		return subject.dataValues;
	},
	async findByManagerId(managerId) {
		let school = await Schools.findOne({
			where: {
				managerId: managerId,
			},
		});
		return school?.dataValues;
	},
	async getClasses(schoolId) {
		let classes = await Classes.findAll({
			where: {
				schoolId: schoolId,
			},
		});
		return classes;
	},
	async getAllSchoolInfo(schoolId) {
		let school = await Schools.findOne({
			where: { id: schoolId },
			include: {
				model: Classes,
				as: 'classes',
				include: [
					{
						model: Sections,
						as: 'sections',
					},
					{
						model: Subjects,
						as: 'subjects',
					},
				],
			},
		});
		return school?.dataValues;
	},
	async getSectionsByClassId(classId) {
		return await Sections.findAll({ where: { classId } });
	},
	async getSubjectsByClassId(classId) {
		return await Subjects.findAll({ where: { classId } });
	},
	async deleteSubject(id) {
		await Subjects.destroy({
			where: {
				id: id,
			},
		});
	},
	async deleteClass(id) {
		await Classes.destroy({
			where: {
				id,
			},
		});
	},
	async deleteSection(id) {
		await Sections.destroy({
			where: {
				id: id,
			},
		});
	},
	async updateClass(classItem, id) {
		await Classes.update(
			{ name: classItem.name },
			{
				where: {
					id: id,
				},
			},
		);
	},
	async updateSubject(subject, id) {
		await Subjects.update(
			{ name: subject.name },
			{
				where: {
					id: id,
				},
			},
		);
	},
	async updateSections(section, id) {
		await Sections.update(
			{ name: section.name },
			{
				where: {
					id: id,
				},
			},
		);
	},
	async updateSchool(school, id) {
		await Schools.update(school, { where: { id } });
	},
};
