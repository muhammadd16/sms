const express = require('express');
const router = express.Router();
const controller = require('./controller');
const validation = require('./validation');
const tokenParser = require('../../../middlewares/token-parser');
const formDataParser = require('../../../middlewares/form-data-parser');
const { roles, canAccess } = require('../../../middlewares/permissions');

// // Create School
router.post(
	'/',
	formDataParser('public/images/schools'),
	tokenParser,
	canAccess([roles.manager]),

	validation.createSchool,
	controller.createSchool,
);

// Get School Info With Classes And Section

router.get('/all', tokenParser, canAccess([roles.manager]), controller.getAllInfo);

// // Update School
router.put(
	'/',
	tokenParser,
	canAccess([roles.manager]),

	formDataParser('public/images/schools'),
	validation.updateSchool,
	controller.updateSchool,
);

// Get Classes
router.get('/class', tokenParser, canAccess([roles.manager, roles.teacher]), controller.getClasses);

// Create Classes
router.post(
	'/class',
	tokenParser,
	canAccess([roles.manager]),
	validation.createClass,
	controller.createClass,
);

// Update Classes
router.put(
	'/class',
	tokenParser,
	canAccess([roles.manager]),
	validation.updateClasses,
	controller.updateClasses,
);

// Delete Classes
router.delete('/class', tokenParser, canAccess([roles.manager]), controller.deleteClasses);

// Get Sections By Class Id
router.get(
	'/section/:classId',
	tokenParser,
	canAccess([roles.manager, roles.teacher]),
	controller.getSectionsByClassId,
);

// Create Sections
router.post(
	'/section',
	tokenParser,
	canAccess([roles.manager]),
	validation.createSections,
	controller.createSections,
);

// Update Sections
router.put(
	'/section',
	tokenParser,
	canAccess([roles.manager]),
	validation.updateSections,
	controller.updateSections,
);

// Delete Sections
router.delete('/section', tokenParser, canAccess([roles.manager]), controller.deleteSections);

// Get Subjects By Class Id
router.get(
	'/subject/:classId',
	tokenParser,
	canAccess([roles.manager, roles.teacher]),
	controller.getSubjectsByClassId,
);

// Create Subjects
router.post(
	'/subject',
	tokenParser,
	canAccess([roles.manager, roles.teacher]),
	validation.createSubjects,
	controller.createSubjects,
);

// Update Subjects
router.put(
	'/subject',
	tokenParser,
	canAccess([roles.manager, roles.teacher]),
	validation.updateSubjects,
	controller.updateSubjects,
);

// Delete Subjects
router.delete(
	'/subject',
	tokenParser,
	canAccess([roles.manager, roles.teacher]),
	controller.deleteSubjects,
);

module.exports = router;
