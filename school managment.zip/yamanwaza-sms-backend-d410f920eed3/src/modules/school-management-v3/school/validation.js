const { body, check } = require('express-validator');
const model = require('./model');

module.exports = {
	createSchool: [
		body('name').notEmpty(),
		body('address').notEmpty(),
		body('phone').notEmpty(),
		body('eduStage').notEmpty(),
		body('__user.role').isIn(['MANAGER']),
		body('__user.id').custom((id) => {
			return model.findByManagerId(id).then((user) => {
				if (user) {
					return Promise.reject('already create');
				}
			});
		}),
	],
	createClass: [
		body('classes').notEmpty(),
		body('classes').isArray(),
		body('classes.*.name').notEmpty(),
	],
	createSubjects: [
		body('subjects').notEmpty(),
		body('subjects').isArray(),
		body('subjects.*.name').notEmpty(),
		body('subjects.*.classId').isInt(),
	],
	createSections: [
		body('sections').notEmpty(),
		body('sections').isArray(),
		body('sections.*.name').notEmpty(),
		body('sections.*.classId').isInt(),
	],
	updateSubjects: [
		body('subjects').notEmpty(),
		body('subjects').isArray(),
		body('subjects.*.name').notEmpty(),
		body('subjects.*.classId').isInt(),
	],
	updateSections: [
		body('sections').notEmpty(),
		body('sections').isArray(),
		body('sections.*.name').notEmpty(),
		body('sections.*.classId').isInt(),
	],
	updateClasses: [
		body('classes').notEmpty(),
		body('classes').isArray(),
		body('classes.*.name').notEmpty(),
	],
	updateSchool: [
		body('name').notEmpty(),
		body('address').notEmpty(),
		body('phone').notEmpty(),
		body('eduStage').notEmpty(),
	],
};
