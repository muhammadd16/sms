const getNextSerial = require('../../../utils/getNextSerial');
const { generatePassword } = require('../../../utils/global');
const Students = require('../../../models/students');
const Classes = require('../../../models/classes');
const Sections = require('../../../models/sections');
const Parents = require('../../../models/parents');

module.exports = {
	async createStudent(body) {
		let schoolId = body.__user.school.id;
		let serial = await getNextSerial('Students', schoolId);
		body.serial = serial;
		body.password = generatePassword();
		body.email = 'student-' + schoolId + '-' + serial + '@e-cademy.edu';
		body.schoolId = schoolId;
		let student = await Students.create(body);

		serial = await getNextSerial('Parents', schoolId);
		await Parents.create({
			schoolId,
			serial,
			childId: student.dataValues.id,
			firstName: body.fatherName,
			lastName: body.lastName,
			email: 'parent-' + schoolId + '-' + serial + '@e-cademy.edu',
			password: generatePassword(),
		});
		return student.dataValues;
	},
	async getStudents(schoolId, { limit, offset }, filters = {}) {
		let data = await Students.findAndCountAll({
			where: { ...filters, schoolId },
			limit,
			offset,
			include: [
				{
					model: Classes,
					as: 'class',
				},
				{
					model: Sections,
					as: 'section',
				},
			],
		});
		data.rows.forEach((student) => {
			student.dataValues.role = 'STUDENT';
		});
		return data;
	},
	async getStudentById(id) {
		let student = await Students.findOne({
			where: { id },
			include: [
				{
					model: Classes,
					as: 'class',
				},
				{
					model: Sections,
					as: 'section',
				},
			],
		});
		student = student?.dataValues;
		if (student) student.role = 'STUDENT';
		return student;
	},
	async updateStudents(student, id) {
		await Students.update(student, { where: { id } });
	},
	async deleteStudent(id) {
		await Students.destroy({ where: { id } });
	},
};
