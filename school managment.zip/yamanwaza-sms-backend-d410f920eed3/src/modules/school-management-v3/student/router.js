const express = require('express');
const router = express.Router();
const controller = require('./controller');
const validation = require('./validation');
const tokenParser = require('../../../middlewares/token-parser');
const formDataParser = require('../../../middlewares/form-data-parser');
const { roles, canAccess } = require('../../../middlewares/permissions');

// Get Student By Id
router.get(
	'/:id',
	tokenParser,
	canAccess([roles.manager, roles.teacher, roles.student, roles.parent]),
	controller.getStudentById,
);

// // Get Students List By Criteria
router.get(
	'/',
	tokenParser,
	canAccess([roles.manager, roles.teacher]),

	controller.getStudents,
);
// get parents list

// // Create Student
router.post(
	'/',
	tokenParser,
	canAccess([roles.manager, roles.teacher]),

	formDataParser('public/images/students'),
	validation.createStudent,
	controller.createStudent,
);

// // Update Student
router.put(
	'/:id',
	tokenParser,
	canAccess([roles.manager, roles.teacher]),

	formDataParser('public/images/students'),
	validation.createStudent,
	controller.updateStudent,
);

// // Delete Student
router.delete(
	'/:id',
	tokenParser,
	canAccess([roles.manager, roles.teacher]),

	controller.deleteStudent,
);

module.exports = router;
