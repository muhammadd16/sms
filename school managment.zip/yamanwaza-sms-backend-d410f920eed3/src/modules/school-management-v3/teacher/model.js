const getNextSerial = require('../../../utils/getNextSerial');
const { generatePassword } = require('../../../utils/global');
const Teachers = require('../../../models/teachers');
const TeacherSections = require('../../../models/teacher-sections');
const TeacherSubjects = require('../../../models/teacher-subjects');
const Subjects = require('../../../models/subjects');

module.exports = {
	async createTeacher(body) {
		let schoolId = body.__user.school.id;
		let serial = await getNextSerial('Teachers', schoolId);
		body.serial = serial;
		body.password = generatePassword();
		body.email = 'teacher-' + schoolId + '-' + serial + '@e-cademy.edu';
		body.schoolId = schoolId;
		body.sections = JSON.parse(body.sections).map((id) => {
			return { sectionId: id };
		});
		body.subjects = JSON.parse(body.subjects).map((id) => {
			return { subjectId: id };
		});
		let teacher = await Teachers.create(body, {
			include: [
				{
					model: TeacherSections,
					as: 'sections',
				},
				{
					model: TeacherSubjects,
					as: 'subjects',
				},
			],
		});
		return teacher.dataValues;
	},
	async getTeachers(schoolId, { limit, offset }, filters = {}) {
		const data = await Teachers.findAndCountAll({
			where: { ...filters, schoolId },
			limit,
			offset,
			include: [
				{
					model: TeacherSections,
					as: 'sections',
				},
				{
					model: TeacherSubjects,
					as: 'subjects',
				},
			],
		});
		data.rows.forEach((teacher) => {
			teacher.dataValues.role = 'TEACHER';
		});
		return data;
	},
	async getTeacherSubjects(teacherId) {
		const data = await TeacherSubjects.findAll({
			where: { teacherId },
			include: [{ model: Subjects, as: 'subject' }],
		});
		return data;
	},
	async updateTeacher(teacher, id) {
		teacher.sections = JSON.parse(teacher.sections).map((id) => {
			return { sectionId: id };
		});
		teacher.subjects = JSON.parse(teacher.subjects).map((id) => {
			return { subjectId: id };
		});
		await Teachers.update(teacher, {
			where: { id },
		});
	},
	async deleteTeacher(id) {
		await Teachers.destroy({ where: { id } });
	},
	async getTeacherById(id) {
		let teacher = await Teachers.findOne({
			where: { id },
			include: [
				{
					model: TeacherSections,
					as: 'sections',
				},
				{
					model: TeacherSubjects,
					as: 'subjects',
				},
			],
		});
		teacher = teacher?.dataValues;
		if (teacher) teacher.role = 'TEACHER';
		return teacher;
	},
};
