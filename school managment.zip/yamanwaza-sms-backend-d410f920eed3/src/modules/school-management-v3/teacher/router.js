const express = require('express');
const router = express.Router();
const controller = require('./controller');
const validation = require('./validation');
const tokenParser = require('../../../middlewares/token-parser');
const formDataParser = require('../../../middlewares/form-data-parser');
const { roles, canAccess } = require('../../../middlewares/permissions');

// Get Teacher By Id
router.get(
	'/:id',
	tokenParser,
	canAccess([roles.manager, roles.teacher]),
	controller.getTeacherById,
);

// // Get Teachers List By Criteria
router.get(
	'/',
	tokenParser,
	canAccess([roles.manager]),

	controller.getTeachers,
);

// Get Teacher Subjects
router.get(
	'/:id/subjects',
	tokenParser,
	canAccess([roles.manager, roles.teacher]),

	controller.getTeacherSubjects,
);

// // Create Teacher
router.post(
	'/',
	tokenParser,
	canAccess([roles.manager]),

	formDataParser('public/images/teachers'),
	validation.createTeacher,
	controller.createTeacher,
);

// // Update Teacher
router.put(
	'/:id',
	tokenParser,
	canAccess([roles.manager]),

	formDataParser('public/images/teachers'),
	validation.createTeacher,
	controller.updateTeacher,
);

// // Delete Teacher
router.delete(
	'/:id',
	tokenParser,
	canAccess([roles.manager]),

	controller.deleteTeacher,
);

module.exports = router;
