const express = require('express');
const { ErrorHandler } = require('../../utils/error');
const { validationResult, body } = require('express-validator');
const { StatusCodes } = require('http-status-codes');
const usersManagementModel = require('./model');
const { defaults } = require('../../utils/config');

module.exports = {
	async createSchool(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				await usersManagementModel.createSchool(req.body);
				res.__send(StatusCodes.CREATED);
			} catch (err) {
				next(err);
			}
		}
	},
	async createStudent(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				await usersManagementModel.createStudent(req.body);
				res.__send(StatusCodes.CREATED);
			} catch (err) {
				next(err);
			}
		}
	},
	async createClass(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let schoolId = req.body.__user.school.id;

				let classes = req.body.classes;
				for (let i = 0; i < classes.length; i++)
					await usersManagementModel.createClass(classes[i], schoolId);
				res.__send(StatusCodes.CREATED);
			} catch (err) {
				next(err);
			}
		}
	},
	async createSections(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let classId = +req.params['classId'];
				let sections = req.body.sections;
				let schoolId = req.body.__user.school.id;

				for (let i = 0; i < sections.length; i++)
					await usersManagementModel.createSections(sections[i], classId, schoolId);

				res.__send(StatusCodes.CREATED);
			} catch (err) {
				next(err);
			}
		}
	},
	async createSubjects(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let classId = +req.params['classId'];
				let subjects = req.body.subjects;
				let schoolId = req.body.__user.school.id;

				for (let i = 0; i < subjects.length; i++)
					await usersManagementModel.createSubjects(subjects[i], classId, schoolId);

				res.__send(StatusCodes.CREATED);
			} catch (err) {
				next(err);
			}
		}
	},
	async createTeacher(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				await usersManagementModel.createTeacher(req.body);
				res.__send(StatusCodes.CREATED);
			} catch (err) {
				next(err);
			}
		}
	},
	async getSchool(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let data = await usersManagementModel.getSchool();
				res.__send(StatusCodes.OK, { data });
			} catch (err) {
				next(err);
			}
		}
	},
	async getTeachers(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let schoolId = req.body.__user.school.id;

				let limit = req.query['limit'] || defaults.limit;
				let offset = req.query['offset'] || defaults.offset;

				let data = await usersManagementModel.getTeacher(schoolId, limit, offset);
				let AllRecord = await usersManagementModel.getTeacher(schoolId, 10000, 0);
				let numberOfAllRecord = AllRecord.length + 1;

				res.__send(StatusCodes.OK, { data, numberOfAllRecord });
			} catch (err) {
				next(err);
			}
		}
	},
	async getClasses(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let schoolId = req.body.__user.school.id;

				let data = await usersManagementModel.getClasses(schoolId);

				res.__send(StatusCodes.OK, { data });
			} catch (err) {
				next(err);
			}
		}
	},
	async getStudents(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let schoolId = req.body.__user.school.id;

				let limit = req.query['limit'] || defaults.limit;
				let offset = req.query['offset'] || defaults.offset;

				let data = await usersManagementModel.getStudent(limit, offset, schoolId);
				let AllRecord = await usersManagementModel.getStudent(1000000, 0, schoolId);
				let numberOfAllRecord = AllRecord.length + 1;

				res.__send(StatusCodes.OK, { data, numberOfAllRecord });
			} catch (err) {
				next(err);
			}
		}
	},
	async getStudentById(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let id = +req.params['id'];

				let data = await usersManagementModel.getStudentById(id);

				res.__send(StatusCodes.OK, data);
			} catch (err) {
				next(err);
			}
		}
	},
	async getTeacherById(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let id = +req.params['id'];

				let data = await usersManagementModel.getTeacherById(id);

				res.__send(StatusCodes.OK, data);
			} catch (err) {
				next(err);
			}
		}
	},
	async getSectionsByClassId(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let classId = +req.params['classId'];
				let schoolId = req.body.__user.school.id;

				let data = await usersManagementModel.getSectionsByClassId(classId, schoolId);

				res.__send(StatusCodes.OK, { data });
			} catch (err) {
				next(err);
			}
		}
	},
	async getSubjectsByClassId(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let classId = +req.params['classId'];
				let schoolId = req.body.__user.school.id;

				let data = await usersManagementModel.getSubjectsByClassId(classId, schoolId);

				res.__send(StatusCodes.OK, { data });
			} catch (err) {
				next(err);
			}
		}
	},

	async deleteSchool(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let schoolId = req.body.__user.school.id;

				await usersManagementModel.deleteSchool(schoolId);
				res.__send(StatusCodes.OK);
			} catch (err) {
				next(err);
			}
		}
		await usersManagementModel.deleteSchool(req.id);
		res.status(StatusCodes.ACCEPTED).json({ message: 'delete teacher succusful' });
	},
	async deleteTeacher(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let id = +req.params['id'];
				let schoolId = req.body.__user.school.id;

				await usersManagementModel.deleteTeacher(id, schoolId);
				res.__send(StatusCodes.OK);
			} catch (err) {
				next(err);
			}
		}
	},
	async deleteClasses(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let classes = req.body.classes;
				let schoolId = req.body.__user.school.id;
				for (let i = 0; i < classes.length; i++)
					await usersManagementModel.deleteClasses(classes[i].id, schoolId);
				res.__send(StatusCodes.OK);
			} catch (err) {
				next(err);
			}
		}
	},
	async deleteSections(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let classId = +req.params['classId'];
				let sections = req.body.sections;

				let schoolId = req.body.__user.school.id;
				for (let i = 0; i < sections.length; i++)
					await usersManagementModel.deleteSections(sections[i].id, classId, schoolId);
				res.__send(StatusCodes.OK);
			} catch (err) {
				next(err);
			}
		}
	},
	async deleteSubjects(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let subjects = req.body.subjects;
				let classId = +req.params['classId'];

				let schoolId = req.body.__user.school.id;
				for (let i = 0; i < subjects.length; i++)
					await usersManagementModel.deleteSubjects(subjects[i].id, classId, schoolId);
				res.__send(StatusCodes.OK);
			} catch (err) {
				next(err);
			}
		}
	},
	async deleteStudent(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let id = +req.params['id'];
				let schoolId = req.body.__user.school.id;

				await usersManagementModel.deleteStudent(id, schoolId);
				res.__send(StatusCodes.OK);
			} catch (err) {
				next(err);
			}
		}
	},

	async updateTeacher(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let teacher = req.body;
				let schoolId = req.body.__user.school.id;
				let id = +req.params['id'];
				await usersManagementModel.updateTeacher(teacher, id, schoolId);
				res.__send(StatusCodes.OK);
			} catch (err) {
				next(err);
			}
		}
	},

	async updateStudent(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let student = req.body;
				let id = +req.params['id'];
				let schoolId = req.body.__user.school.id;
				await usersManagementModel.updateStudents(student, id, schoolId);
				res.__send(StatusCodes.OK);
			} catch (err) {
				next(err);
			}
		}
	},
	async updateClasses(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let classes = req.body.classes;
				let schoolId = req.body.__user.school.id;
				for (let i = 0; i < classes.length; i++)
					await usersManagementModel.updateClasses(classes[i], classes[i].id, schoolId);
				res.__send(StatusCodes.OK);
			} catch (err) {
				next(err);
			}
		}
	},
	async updateSubjects(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let subjects = req.body.subjects;
				let classId = +req.params['classId'];

				let schoolId = req.body.__user.school.id;
				for (let i = 0; i < subjects.length; i++)
					await usersManagementModel.updateٍSubjects(
						subjects[i],
						subjects[i].id,
						classId,
						schoolId,
					);
				res.__send(StatusCodes.OK);
			} catch (err) {
				next(err);
			}
		}
	},
	async updateSections(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let classId = +req.params['classId'];
				let schoolId = req.body.__user.school.id;

				let sections = req.body.sections;
				for (let i = 0; i < sections.length; i++)
					await usersManagementModel.updateSections(
						sections[i],
						sections[i].id,
						classId,
						schoolId,
					);
				res.__send(StatusCodes.OK);
			} catch (err) {
				next(err);
			}
		}
	},
	async updateSchool(req, res, next) {
		const errors = validationResult(req);
		if (!errors.isEmpty()) {
			next(new ErrorHandler(StatusCodes.NOT_ACCEPTABLE, 'Input Error', errors.array()));
		} else {
			try {
				let id = +req.params['id'];
				let school = req.body;

				await usersManagementModel.updateSchool(school, id);
				res.__send(StatusCodes.OK);
			} catch (err) {
				next(err);
			}
		}
	},
};
