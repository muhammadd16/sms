const { request } = require('express');
const db = require('../../services/db');
const getNextId = require('../../utils/getNextId');
const { generatePassword } = require('../../utils/global');

module.exports = {
	async createSchool(body) {
		var sql = `INSERT INTO Schools
            (
                 name, address, phone , eduStage ,logo ,managerId
            )
            VALUES
            (
                ?, ?, ?, ?, ?, ?
            )`;
		var managerId = body.__user.id;
		var name = body.name;
		var address = body.address;
		var phone = body.phone;
		var logo = body.logo || '';
		var educationalStage = body.educationalStage;

		let values = [name, address, phone, educationalStage, logo, managerId];
		await db.query(sql, values);
	},
	async createStudent(body) {
		let schoolId = body.__user.school.id;

		let id = await getNextId('Students', schoolId);
		var sql = `INSERT INTO Students
		(
			id,fatherName, motherName, schoolId, classId , sectionId ,firstName , lastName ,gender , email, password ,picture
		)
		VALUES
		(
			?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
		)`;
		var fatherName = body.fatherName;
		var motherName = body.motherName;
		var gender = body.gender;
		var classId = body.classId;
		var sectionId = body.sectionId;
		var firstName = body.firstName;
		var lastName = body.lastName;
		var email = 'student-' + schoolId + '-' + id + '@e-cademy.edu';
		var password = generatePassword();
		var picture = body.picture;

		let values = [
			id,
			fatherName,
			motherName,
			schoolId,
			classId,
			sectionId,
			firstName,
			lastName,
			gender,
			email,
			password,
			picture,
		];
		await db.query(sql, values);
	},
	async createClass(body, schoolId) {
		let id = await getNextId('Classes', schoolId);
		var sql = `INSERT INTO Classes
		(
			id,schoolId,name
		)
		VALUES
		(
			?, ?, ?
		)`;
		var name = body.name;
		let values = [id, schoolId, name];
		await db.query(sql, values);
	},
	async createSections(body, classId, schoolId) {
		let id = await getNextId('Sections', schoolId);
		var sql = `INSERT INTO Sections
		(
			id,schoolId,classId,name
		)
		VALUES
		(
			?, ?, ?, ?
		)`;
		var name = body.name;
		let values = [id, schoolId, classId, name];
		await db.query(sql, values);
	},
	async createSubjects(body, classId, schoolId) {
		let id = await getNextId('Subjects', schoolId);
		var sql = `INSERT INTO Subjects
		(
			id,classId,name,schoolId
		)
		VALUES
		(
			?, ?, ?, ?
		)`;
		var name = body.name;
		let values = [id, classId, name, schoolId];
		await db.query(sql, values);
	},
	async getSchool() {
		var sql = `SELECT * FROM Schools `;

		let results = await db.query(sql);

		return results;
	},
	async getTeacher(limit, offset, schoolId) {
		var sql = `SELECT * FROM Teachers WHERE schoolId= ?  LIMIT ? OFFSET ? `;

		let results = await db.query(sql, [schoolId, limit, offset]);
		return results;
	},
	async getClasses(schoolId) {
		var sql = `SELECT * FROM Classes WHERE schoolId = ?  `;

		let results = await db.query(sql, [schoolId]);
		return results;
	},
	async getStudent(limit, offset, schoolId) {
		var sql = `SELECT * FROM Students WHERE schoolId= ?  LIMIT ? OFFSET ? `;

		let results = await db.query(sql, [schoolId, limit, offset]);
		return results;
	},

	async createTeacher(body) {
		var schoolId = body.__user.school.id;
		let id = await getNextId('Teachers', schoolId);

		var sql = ` 
		
		INSERT INTO Teachers
		(
			id,schoolId,firstName,lastName,picture,gender,email,password,grade
		)
		VALUES
		(
			?,?,?,?,?,?,?,?,?
		);
		 `;
		var firstName = body.firstName;
		var lastName = body.lastName;
		var gender = body.gender;
		var grade = body.grade;
		var email = 'teacher-' + schoolId + '-' + id + '@e-cademy.edu';
		var picture = body.picture;
		var password = generatePassword();
		console.log('school', schoolId, id);

		let values = [id, schoolId, firstName, lastName, picture, gender, email, password, grade];
		await db.query(sql, values);
	},

	findByname(name, callback) {
		db.query('SELECT * FROM School  WHERE name = ?', [name], (error, results) => {
			let result = results && results.length ? results[0] : undefined;
			callback(error, result);
		});
	},
	async updateTeacher(teacher, id, schoolId) {
		let query =
			'UPDATE Teachers SET grade = ?, firstName = ? ,lastName = ?,gender = ?,email = ?,password =?, picture=? WHERE id= ? AND schoolId = ? ';
		let values = [
			teacher.grade,
			teacher.firstName,
			teacher.lastName,
			teacher.gender,
			teacher.email,
			teacher.password,
			teacher.picture,
			id,
			schoolId,
		];
		await db.query(query, values);
	},
	async updateٍSubjects(subjects, id, classId, schoolId) {
		let query = 'UPDATE Subjects SET  name = ? WHERE id= ? AND schoolId = ? AND classId = ? ';

		await db.query(query, [subjects.name, id, schoolId, classId]);
	},
	async updateSections(sections, id, classId, schoolId) {
		let query = 'UPDATE Sections SET  name = ? WHERE id= ? AND schoolId = ? AND classId = ? ';

		await db.query(query, [sections.name, id, schoolId, classId]);
	},

	async updateStudents(student, id, schoolId) {
		let query =
			'UPDATE Students SET fatherName = ?, motherName = ? ,classId = ?,sectionId = ?,firstName = ?,lastName =?, gender=?,email=? ,password=? ,picture=? WHERE id= ? AND schoolId = ? ';
		let values = [
			student.fatherName,
			student.motherName,
			student.classId,
			student.sectionId,
			student.firstName,
			student.lastName,
			student.gender,
			student.email,
			student.password,
			student.picture,
			id,
			schoolId,
		];
		await db.query(query, values);
	},
	async updateClasses(classes, id, schoolId) {
		let query = 'UPDATE Classes SET name = ?  WHERE id= ? AND schoolId = ? ';

		await db.query(query, [classes.name, id, schoolId]);
	},

	async updateSchool(school, id) {
		let query =
			'UPDATE Schools SET name = ?,address = ?, phone = ?,eduStage = ?,logo = ?, managerId= ? WHERE id= ?  ';
		let values = [
			school.name,
			school.address,
			school.phone,
			school.eduStage,
			school.logo,
			school.managerId,
			id,
		];
		await db.query(query, values);
	},
	async deleteTeacher(id, schoolId) {
		let query = `DELETE FROM Teachers WHERE id = ? AND schoolId = ? `;
		await db.query(query, [id, schoolId]);
	},
	async deleteStudent(id, schoolId) {
		let query = `DELETE FROM Students WHERE id = ? AND schoolId = ? `;
		await db.query(query, [id, schoolId]);
	},
	async deleteClasses(id, schoolId) {
		let query = `DELETE FROM Classes WHERE id = ? AND schoolId = ? `;
		await db.query(query, [id, schoolId]);
	},
	async deleteSections(id, classId, schoolId) {
		let query = `DELETE FROM Sections WHERE id = ? AND classId = ?  AND schoolId = ? `;
		await db.query(query, [id, classId, schoolId]);
	},
	async deleteSubjects(id, classId, schoolId) {
		let query = `DELETE FROM Subjects WHERE id = ? AND classId = ?  AND schoolId = ? `;
		await db.query(query, [id, classId, schoolId]);
	},

	async deleteSchool(id) {
		let sql = `DELETE FROM Schools WHERE id = ? `;
		await db.query(sql, [id]);
	},
	async getSchoolByManager(managerId) {
		let sql = `SELECT * FROM Schools WHERE managerId = ?`;
		let res = await db.query(sql, [managerId]);
		res = res && res.length ? res[0] : undefined;
		return res;
	},
	async getSchoolById(id) {
		let sql = `SELECT * FROM Schools WHERE id = ?`;
		let res = await db.query(sql, [id]);
		res = res && res.length ? res[0] : undefined;
		return res;
	},
	async getStudentById(id) {
		let sql = `SELECT * FROM Students WHERE id = ?`;
		let res = await db.query(sql, [id]);
		res = res && res.length ? res[0] : undefined;
		return res;
	},
	async getSectionsByClassId(classId, schoolId) {
		let sql = `SELECT * FROM Sections WHERE classId = ? AND schoolId = ? `;
		let res = await db.query(sql, [classId, schoolId]);

		return res;
	},
	async getSubjectsByClassId(classId, schoolId) {
		let sql = `SELECT * FROM Subjects WHERE classId = ? AND schoolId = ? `;
		let res = await db.query(sql, [classId, schoolId]);

		return res;
	},
	async getTeacherById(id) {
		let sql = `SELECT * FROM Teachers WHERE id = ?`;
		let res = await db.query(sql, [id]);
		res = res && res.length ? res[0] : undefined;
		return res;
	},
};
