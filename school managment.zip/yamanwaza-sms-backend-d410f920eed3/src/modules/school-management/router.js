const express = require('express');
const router = express.Router();
const userManagementController = require('./controller');
const uploadImage = require('../../middlewares/upload-image');
const usersValidations = require('./validation');
const tokenParser = require('../../middlewares/token-parser');
const formDataParser = require('../../middlewares/form-data-parser');

router.post(
	'/create-school',
	tokenParser,
	formDataParser,
	usersValidations.createSchool,
	/// uploadImage('schools').single('logo'),
	userManagementController.createSchool,
);
router.post('/create-teacher', formDataParser,tokenParser, userManagementController.createTeacher);
router.post('/create-student', formDataParser,tokenParser, userManagementController.createStudent);
router.post('/create-class',tokenParser, userManagementController.createClass);
router.post('/create-sections/:classId', tokenParser, userManagementController.createSections);

router.post('/create-subjects/:classId',tokenParser, userManagementController.createSubjects);

router.put('/update-school/:id', userManagementController.updateSchool);
router.put('/update-classes',tokenParser, userManagementController.updateClasses);
router.put('/update-subjects/:classId',tokenParser, userManagementController.updateSubjects);
router.put('/update-sections/:classId',tokenParser, userManagementController.updateSections);


router.get('/get-school', userManagementController.getSchool);
router.delete('/delete-school',tokenParser, userManagementController.deleteSchool);
router.delete('/delete-teacher/:id', tokenParser, userManagementController.deleteTeacher);
router.delete('/delete-student/:id', tokenParser, userManagementController.deleteStudent);
router.delete('/delete-classes', tokenParser, userManagementController.deleteClasses);
router.delete('/delete-sections/:classId', tokenParser, userManagementController.deleteSections);
router.delete('/delete-subjects/:classId', tokenParser, userManagementController.deleteSubjects);



router.put('/update-teacher/:id',  formDataParser,tokenParser, userManagementController.updateTeacher);
router.put('/update-student/:id',  formDataParser,tokenParser, userManagementController.updateStudent);
router.get('/get-students',tokenParser, userManagementController.getStudents);
router.get('/get-sections-by-classId/:classId',tokenParser, userManagementController.getSectionsByClassId);
router.get('/get-subjects-by-classId/:classId',tokenParser, userManagementController.getSubjectsByClassId);


router.get('/get-student-by-id/:id', userManagementController.getStudentById);
router.get('/get-teacher-by-id/:id', userManagementController.getTeacherById);


router.get('/get-teachers',tokenParser, userManagementController.getTeachers);
router.get('/get-classes',tokenParser, userManagementController.getClasses);

module.exports = router;
