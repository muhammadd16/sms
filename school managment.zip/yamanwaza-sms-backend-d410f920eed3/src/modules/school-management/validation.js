const { body } = require('express-validator');
const AuthModel = require('./model');

module.exports = {
	createSchool: [body('name').notEmpty(), body('address').notEmpty(), body('phone').notEmpty()],
};
