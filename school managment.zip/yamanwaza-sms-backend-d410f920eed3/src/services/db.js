const mysql = require('mysql2');
const config = require('../utils/config');
const pool = mysql.createPool(config.db);

function query(sql, values) {
	return new Promise((resolve, reject) => {
		pool.query(sql, values, (err, rows) => {
			if (err) return reject(err);
			return resolve(rows);
		});
	});
}

module.exports = {
	query,
};
