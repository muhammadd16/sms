const nodemailer = require('nodemailer');
const config = require('../utils/config');

const transporter = nodemailer.createTransport(config.mailer);

function sendMail(to, subject, text) {
	// let options = {
	// 	from: config.mailer.auth.user,
	// 	to,
	// 	subject,
	// 	text,
	// };
	// transporter.sendMail(options, (error, info) => {
	// 	if (error) {
	// 		console.log(error);
	// 	} else {
	// 		console.log('Email sent: ' + info.response);
	// 	}
	// });
}

module.exports = {
	sendMail,
};
