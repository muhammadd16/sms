const { query } = require('../services/db');

module.exports = async (tableName, schoolId) => {
	let sql = `SELECT * from ${tableName} WHERE schoolId = ?`;
	let result = await query(sql, [schoolId]);
	if (!result.length) return 1;
	let Res = 1 + Math.max(...result.map((row) => row.serial));
	if (!Res) return 1;
	return Res;
};
