const { query } = require('../services/db');

module.exports = async (tableName, schoolId) => {
	let cmd = `SELECT COUNT(*) FROM ${tableName} WHERE schoolId = ${schoolId}`;
	let result = await query(cmd);
	result = result[0]['COUNT(*)'];
	return result;
};
